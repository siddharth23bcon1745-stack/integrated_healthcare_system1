import { useState, useEffect } from "react";
import {
  Activity, Calendar, FileText, Bell, MessageSquare, Users,
  LogOut, ChevronRight, Clock, Heart, Pill, AlertTriangle,
  User, Stethoscope, Shield, Plus, Search, X, Check,
  TrendingUp, Database, Settings, Home, Eye, Edit,
  Phone, Mail, MapPin, Droplet, ChevronDown, CheckCircle,
  XCircle, BarChart2, ClipboardList, UserCheck, Zap
} from "lucide-react";

// ─── Palette & Theme ────────────────────────────────────────────────────────
const API_URL = "http://127.0.0.1:5000/api";
const C = {
  navy: "#0A2342",
  navyMid: "#123264",
  navyLight: "#1E4080",
  accent: "#2E86AB",
  accentLight: "#4EA8C9",
  gold: "#D4A843",
  white: "#F8FAFC",
  gray50: "#F1F5F9",
  gray100: "#E2E8F0",
  gray400: "#94A3B8",
  gray600: "#475569",
  gray800: "#1E293B",
  green: "#10B981",
  red: "#EF4444",
  amber: "#F59E0B",
};

// ─── Seed Data (mirrors DB schema from report) ───────────────────────────────
const USERS = [
  { user_id: 1, username: "patient1", email: "arjun.sharma@email.com", role: "patient", is_active: true },
  { user_id: 2, username: "dr.mehta", email: "dr.mehta@hospital.com", role: "doctor", is_active: true },
  { user_id: 3, username: "admin", email: "admin@hospital.com", role: "admin", is_active: true },
];

const PATIENTS = [
  { patient_id: 1, user_id: 1, full_name: "Arjun Sharma", date_of_birth: "1990-04-15", gender: "Male", blood_group: "B+", phone: "9876543210", address: "12 Tonk Road, Jaipur", emergency_contact: "Priya Sharma – 9876543211" },
  { patient_id: 2, user_id: 4, full_name: "Meera Patel", date_of_birth: "1985-09-22", gender: "Female", blood_group: "O+", phone: "9812345678", address: "45 C-Scheme, Jaipur", emergency_contact: "Ravi Patel – 9812345679" },
  { patient_id: 3, user_id: 5, full_name: "Rahul Gupta", date_of_birth: "2000-01-10", gender: "Male", blood_group: "A-", phone: "9923456789", address: "7 Vaishali Nagar, Jaipur", emergency_contact: "Suman Gupta – 9923456780" },
];

const DOCTORS = [
  { doctor_id: 1, user_id: 2, full_name: "Dr. Rakesh Mehta", specialization: "Cardiology", qualification: "MBBS, MD (Cardiology)", registration_no: "RJ-MED-2048", consultation_fee: 800 },
  { doctor_id: 2, user_id: 6, full_name: "Dr. Sunita Agarwal", specialization: "General Medicine", qualification: "MBBS, MD (Gen. Med)", registration_no: "RJ-MED-3192", consultation_fee: 500 },
  { doctor_id: 3, user_id: 7, full_name: "Dr. Vikram Joshi", specialization: "Orthopedics", qualification: "MBBS, MS (Ortho)", registration_no: "RJ-MED-4201", consultation_fee: 700 },
];

const APPOINTMENTS_INIT = [
  { appointment_id: 1, patient_id: 1, doctor_id: 1, appointment_date: "2026-05-12", appointment_time: "10:00", status: "Scheduled", notes: "Follow-up for chest pain" },
  { appointment_id: 2, patient_id: 2, doctor_id: 2, appointment_date: "2026-05-10", appointment_time: "14:30", status: "Completed", notes: "Routine checkup" },
  { appointment_id: 3, patient_id: 3, doctor_id: 3, appointment_date: "2026-05-14", appointment_time: "11:00", status: "Scheduled", notes: "Knee pain assessment" },
  { appointment_id: 4, patient_id: 1, doctor_id: 2, appointment_date: "2026-04-28", appointment_time: "09:00", status: "Completed", notes: "Fever and cold" },
];

const HEALTH_RECORDS = [
  { record_id: 1, patient_id: 1, doctor_id: 1, visit_date: "2026-04-28", diagnosis: "Viral Fever, Common Cold", prescription: "Paracetamol 500mg – 3x daily; Cetirizine 10mg – 1x at night", lab_reports: "CBC, Thyroid Panel", follow_up_date: "2026-05-12" },
  { record_id: 2, patient_id: 1, doctor_id: 2, visit_date: "2026-03-10", diagnosis: "Hypertension – Stage 1", prescription: "Amlodipine 5mg – 1x daily; Low-sodium diet advised", lab_reports: "Lipid Profile, ECG", follow_up_date: "2026-04-10" },
  { record_id: 3, patient_id: 2, doctor_id: 2, visit_date: "2026-05-10", diagnosis: "Type 2 Diabetes (controlled)", prescription: "Metformin 500mg – 2x daily; Monitor fasting glucose weekly", lab_reports: "HbA1c, FBS", follow_up_date: "2026-07-10" },
];

const MEDICATIONS_INIT = [
  { medication_id: 1, patient_id: 1, medicine_name: "Amlodipine", dosage: "5mg", frequency: "Daily", start_date: "2026-03-10", end_date: "2026-06-10", reminder_time: "08:00" },
  { medication_id: 2, patient_id: 1, medicine_name: "Paracetamol", dosage: "500mg", frequency: "3x Daily", start_date: "2026-04-28", end_date: "2026-05-05", reminder_time: "07:00" },
  { medication_id: 3, patient_id: 2, medicine_name: "Metformin", dosage: "500mg", frequency: "Twice Daily", start_date: "2026-05-10", end_date: "2026-11-10", reminder_time: "07:30" },
];

// Time slots pool for scheduling
const TIME_SLOTS = ["09:00","09:30","10:00","10:30","11:00","11:30","14:00","14:30","15:00","15:30","16:00","16:30"];

// ─── Tiny UI Atoms ────────────────────────────────────────────────────────────
const Badge = ({ label, color }) => {
  const map = { Scheduled: [C.accent, "#EFF8FF"], Completed: [C.green, "#ECFDF5"], Cancelled: [C.red, "#FEF2F2"], Active: [C.green, "#ECFDF5"], Inactive: [C.gray400, C.gray50] };
  const [fg, bg] = map[color] || map[label] || [C.gray600, C.gray100];
  return <span style={{ background: bg, color: fg, border: `1px solid ${fg}33`, borderRadius: 20, padding: "2px 10px", fontSize: 12, fontWeight: 600, letterSpacing: 0.3 }}>{label}</span>;
};

const Card = ({ children, style = {} }) => (
  <div style={{ background: "#fff", borderRadius: 12, boxShadow: "0 2px 12px rgba(10,35,66,0.08)", border: `1px solid ${C.gray100}`, ...style }}>
    {children}
  </div>
);

const Stat = ({ icon: Icon, label, value, sub, accent }) => (
  <Card style={{ padding: "20px 24px", display: "flex", alignItems: "center", gap: 16 }}>
    <div style={{ background: accent || C.navy, borderRadius: 10, padding: 12, flexShrink: 0 }}>
      <Icon size={22} color="#fff" />
    </div>
    <div>
      <div style={{ fontSize: 26, fontWeight: 700, color: C.navy, lineHeight: 1 }}>{value}</div>
      <div style={{ fontSize: 13, color: C.gray600, marginTop: 3 }}>{label}</div>
      {sub && <div style={{ fontSize: 11, color: C.accent, marginTop: 2 }}>{sub}</div>}
    </div>
  </Card>
);

const Btn = ({ children, onClick, variant = "primary", style = {}, disabled }) => {
  const styles = {
    primary: { background: C.navy, color: "#fff", border: "none" },
    outline: { background: "transparent", color: C.navy, border: `1.5px solid ${C.navy}` },
    accent: { background: C.accent, color: "#fff", border: "none" },
    danger: { background: C.red, color: "#fff", border: "none" },
    ghost: { background: "transparent", color: C.gray600, border: `1px solid ${C.gray100}` },
  };
  return (
    <button onClick={onClick} disabled={disabled}
      style={{ ...styles[variant], borderRadius: 8, padding: "8px 18px", fontSize: 13, fontWeight: 600, cursor: disabled ? "not-allowed" : "pointer", opacity: disabled ? 0.5 : 1, display: "flex", alignItems: "center", gap: 6, transition: "opacity 0.15s", ...style }}>
      {children}
    </button>
  );
};

const Input = ({ label, value, onChange, type = "text", options, style = {} }) => (
  <div style={{ display: "flex", flexDirection: "column", gap: 4, ...style }}>
    {label && <label style={{ fontSize: 12, fontWeight: 600, color: C.gray600, letterSpacing: 0.4 }}>{label.toUpperCase()}</label>}
    {options ? (
      <select value={value} onChange={e => onChange(e.target.value)}
        style={{ border: `1.5px solid ${C.gray100}`, borderRadius: 8, padding: "8px 12px", fontSize: 13, color: C.navy, outline: "none", background: "#fff" }}>
        {options.map(o => <option key={o.value || o} value={o.value || o}>{o.label || o}</option>)}
      </select>
    ) : (
      <input type={type} value={value} onChange={e => onChange(e.target.value)}
        style={{ border: `1.5px solid ${C.gray100}`, borderRadius: 8, padding: "8px 12px", fontSize: 13, color: C.navy, outline: "none" }} />
    )}
  </div>
);

const Modal = ({ title, onClose, children }) => (
  <div style={{ position: "fixed", inset: 0, background: "rgba(10,35,66,0.55)", zIndex: 1000, display: "flex", alignItems: "center", justifyContent: "center", padding: 16 }}>
    <Card style={{ width: "100%", maxWidth: 520, padding: 28, position: "relative", maxHeight: "90vh", overflowY: "auto" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
        <h3 style={{ margin: 0, color: C.navy, fontSize: 18, fontWeight: 700 }}>{title}</h3>
        <button onClick={onClose} style={{ background: "none", border: "none", cursor: "pointer", color: C.gray400 }}><X size={20} /></button>
      </div>
      {children}
    </Card>
  </div>
);

// ─── LOGIN SCREEN ─────────────────────────────────────────────────────────────
const Login = ({ onLogin }) => {
  const [email, setEmail] = useState("arjun.sharma@email.com");
  const [password, setPassword] = useState("Patient@123");
  const [role, setRole] = useState("patient");
  const [error, setError] = useState("");

  const [loading, setLoading] = useState(false);

  const handle = async () => {
    setLoading(true); setError("");
    try {
      const res = await fetch(`${API_URL}/auth/login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password })
      });
      const data = await res.json();
      if (res.ok) {
        onLogin(data);
      } else {
        setError(data.error || "Login failed");
      }
    } catch (err) {
      setError("Network error");
    } finally {
      setLoading(false);
    }
  };

  const quickLogin = (r) => {
    const defaults = { patient: ["arjun.sharma@email.com", "Patient@123"], doctor: ["dr.mehta@hospital.com", "Doctor@123"], admin: ["admin@hospital.com", "Admin@123"] };
    setRole(r); setEmail(defaults[r][0]); setPassword(defaults[r][1]); setError("");
  };

  return (
    <div style={{ minHeight: "100vh", background: `linear-gradient(135deg, ${C.navy} 0%, ${C.navyLight} 60%, ${C.accent} 100%)`, display: "flex", alignItems: "center", justifyContent: "center", padding: 16 }}>
      <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 24, width: "100%", maxWidth: 420 }}>
        {/* Logo */}
        <div style={{ textAlign: "center" }}>
          <div style={{ background: "rgba(255,255,255,0.12)", borderRadius: 20, padding: "16px 20px", display: "inline-flex", alignItems: "center", gap: 12, marginBottom: 12 }}>
            <Activity size={32} color={C.gold} />
            <div style={{ textAlign: "left" }}>
            <div style={{ color: "#fff", fontWeight: 800, fontSize: 18, letterSpacing: 0.5 }}>Medi Vault HMS</div>
              <div style={{ color: "rgba(255,255,255,0.6)", fontSize: 11, letterSpacing: 1 }}>INTEGRATED HEALTHCARE MANAGEMENT</div>
            </div>
          </div>
          <div style={{ color: "rgba(255,255,255,0.5)", fontSize: 12 }}>JECRC University — Minor Project 2025-26</div>
        </div>

        <Card style={{ width: "100%", padding: 32 }}>
          <h2 style={{ margin: "0 0 6px", color: C.navy, fontWeight: 700, fontSize: 22 }}>Sign In</h2>
          <p style={{ margin: "0 0 24px", color: C.gray600, fontSize: 13 }}>Access your healthcare portal</p>

          {/* Quick Role Select */}
          <div style={{ display: "flex", gap: 8, marginBottom: 20 }}>
            {["patient","doctor","admin"].map(r => (
              <button key={r} onClick={() => quickLogin(r)}
                style={{ flex: 1, padding: "8px 4px", borderRadius: 8, border: `1.5px solid ${role === r ? C.navy : C.gray100}`, background: role === r ? C.navy : "#fff", color: role === r ? "#fff" : C.gray600, fontSize: 12, fontWeight: 600, cursor: "pointer", textTransform: "capitalize" }}>
                {r}
              </button>
            ))}
          </div>

          <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
            <Input label="Email" value={email} onChange={setEmail} type="email" />
            <Input label="Password" value={password} onChange={setPassword} type="password" />
            {error && <div style={{ color: C.red, fontSize: 12, background: "#FEF2F2", padding: "8px 12px", borderRadius: 6 }}>{error}</div>}
            <Btn onClick={handle} disabled={loading} style={{ width: "100%", justifyContent: "center", padding: "11px 18px", fontSize: 14, marginTop: 4 }}>
              {loading ? "Signing in..." : <>Sign In <ChevronRight size={16} /></>}
            </Btn>
          </div>

          <div style={{ marginTop: 20, padding: "12px 14px", background: C.gray50, borderRadius: 8, fontSize: 11, color: C.gray600, lineHeight: 1.7 }}>
            <strong>Demo Accounts:</strong><br />
            Patient · Doctor · Admin — click role buttons above to auto-fill
          </div>
        </Card>
      </div>
    </div>
  );
};

// ─── SIDEBAR ──────────────────────────────────────────────────────────────────
const Sidebar = ({ role, active, setActive, onLogout }) => {
  const menus = {
    patient: [
      { id: "dashboard", icon: Home, label: "Dashboard" },
      { id: "appointments", icon: Calendar, label: "Appointments" },
      { id: "records", icon: FileText, label: "Health Records" },
      { id: "medications", icon: Pill, label: "Medications" },
      { id: "messages", icon: MessageSquare, label: "Messages" },
    ],
    doctor: [
      { id: "dashboard", icon: Home, label: "Dashboard" },
      { id: "patients", icon: Users, label: "My Patients" },
      { id: "appointments", icon: Calendar, label: "Appointments" },
      { id: "records", icon: FileText, label: "Health Records" },
    ],
    admin: [
      { id: "dashboard", icon: Home, label: "Dashboard" },
      { id: "users", icon: Users, label: "User Management" },
      { id: "appointments", icon: Calendar, label: "All Appointments" },
      { id: "analytics", icon: BarChart2, label: "Analytics" },
      { id: "settings", icon: Settings, label: "System Config" },
    ],
  };

  const roleLabels = { patient: "Patient Portal", doctor: "Doctor Portal", admin: "Admin Panel" };
  const roleIcons = { patient: User, doctor: Stethoscope, admin: Shield };
  const RoleIcon = roleIcons[role];

  return (
    <div style={{ width: 230, minHeight: "100vh", background: C.navy, display: "flex", flexDirection: "column", flexShrink: 0 }}>
      {/* Header */}
      <div style={{ padding: "24px 20px 20px", borderBottom: "1px solid rgba(255,255,255,0.08)" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 4 }}>
          <Activity size={22} color={C.gold} />
          <span style={{ color: "#fff", fontWeight: 800, fontSize: 16, letterSpacing: 0.3 }}>Medi Vault</span>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 8, marginTop: 14 }}>
          <div style={{ background: "rgba(255,255,255,0.12)", borderRadius: 8, padding: 6 }}><RoleIcon size={14} color="rgba(255,255,255,0.8)" /></div>
          <span style={{ color: "rgba(255,255,255,0.6)", fontSize: 11, fontWeight: 600, letterSpacing: 0.5 }}>{roleLabels[role].toUpperCase()}</span>
        </div>
      </div>

      {/* Nav */}
      <nav style={{ flex: 1, padding: "12px 10px" }}>
        {menus[role].map(({ id, icon: Icon, label }) => {
          const isActive = active === id;
          return (
            <button key={id} onClick={() => setActive(id)}
              style={{ width: "100%", display: "flex", alignItems: "center", gap: 11, padding: "10px 12px", borderRadius: 8, border: "none", background: isActive ? "rgba(46,134,171,0.3)" : "transparent", color: isActive ? "#fff" : "rgba(255,255,255,0.55)", fontSize: 13, fontWeight: isActive ? 600 : 400, cursor: "pointer", marginBottom: 2, textAlign: "left", transition: "all 0.15s", borderLeft: isActive ? `3px solid ${C.accentLight}` : "3px solid transparent" }}>
              <Icon size={16} />
              {label}
            </button>
          );
        })}
      </nav>

      {/* Logout */}
      <div style={{ padding: "16px 10px", borderTop: "1px solid rgba(255,255,255,0.08)" }}>
        <button onClick={onLogout}
          style={{ width: "100%", display: "flex", alignItems: "center", gap: 11, padding: "10px 12px", borderRadius: 8, border: "none", background: "transparent", color: "rgba(255,255,255,0.45)", fontSize: 13, cursor: "pointer" }}>
          <LogOut size={16} /> Sign Out
        </button>
      </div>
    </div>
  );
};

// ─── TOPBAR ───────────────────────────────────────────────────────────────────
const TopBar = ({ title, userName }) => (
  <div style={{ background: "#fff", borderBottom: `1px solid ${C.gray100}`, padding: "0 28px", height: 60, display: "flex", alignItems: "center", justifyContent: "space-between", flexShrink: 0 }}>
    <h1 style={{ margin: 0, fontSize: 18, fontWeight: 700, color: C.navy }}>{title}</h1>
    <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
      <div style={{ position: "relative" }}>
        <Bell size={18} color={C.gray400} />
        <div style={{ position: "absolute", top: -3, right: -3, width: 8, height: 8, background: C.red, borderRadius: "50%", border: "1.5px solid #fff" }} />
      </div>
      <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
        <div style={{ width: 32, height: 32, borderRadius: "50%", background: `linear-gradient(135deg, ${C.navy}, ${C.accent})`, display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontSize: 13, fontWeight: 700 }}>
          {userName?.charAt(0)?.toUpperCase()}
        </div>
        <span style={{ fontSize: 13, fontWeight: 600, color: C.navy }}>{userName}</span>
      </div>
    </div>
  </div>
);

// ─── PATIENT DASHBOARD ────────────────────────────────────────────────────────
const PatientDashboard = ({ auth }) => {
  const [upcoming, setUpcoming] = useState([]);
  const [myMeds, setMyMeds] = useState([]);

  useEffect(() => {
    fetch(`${API_URL}/appointments`, { headers: { Authorization: `Bearer ${auth.access_token}` } })
      .then(r => r.json())
      .then(data => { if (Array.isArray(data)) setUpcoming(data.filter(a => a.status === "Scheduled")); })
      .catch(console.error);
    fetch(`${API_URL}/medications`, { headers: { Authorization: `Bearer ${auth.access_token}` } })
      .then(r => r.json())
      .then(data => { if (Array.isArray(data)) setMyMeds(data); })
      .catch(console.error);
  }, [auth.access_token]);

  const patient = auth.user_info || {};

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 24 }}>
      {/* Welcome banner */}
      <div style={{ background: `linear-gradient(120deg, ${C.navy} 0%, ${C.navyLight} 100%)`, borderRadius: 14, padding: "24px 28px", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div>
          <div style={{ color: "rgba(255,255,255,0.6)", fontSize: 12, marginBottom: 4, letterSpacing: 0.5 }}>GOOD MORNING</div>
          <div style={{ color: "#fff", fontSize: 22, fontWeight: 700 }}>{patient.full_name}</div>
          <div style={{ color: "rgba(255,255,255,0.55)", fontSize: 12, marginTop: 6 }}>Blood Group: <strong style={{ color: C.gold }}>{patient.blood_group}</strong> · DOB: {patient.date_of_birth}</div>
        </div>
        <div style={{ textAlign: "right" }}>
          <div style={{ color: "rgba(255,255,255,0.5)", fontSize: 11 }}>Patient ID</div>
          <div style={{ color: C.gold, fontWeight: 700, fontSize: 18 }}>P-{String(auth.entity_id).padStart(4,"0")}</div>
        </div>
      </div>

      {/* Stats */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))", gap: 16 }}>
        <Stat icon={Calendar} label="Upcoming Appointments" value={upcoming.length} sub="Next: May 12" accent={C.accent} />
        <Stat icon={FileText} label="Health Records" value={HEALTH_RECORDS.filter(r => r.patient_id === auth.entity_id).length} sub="View all records" accent={C.navyLight} />
        <Stat icon={Pill} label="Active Medications" value={myMeds.filter(m => !m.end_date || new Date(m.end_date) >= new Date()).length} sub="Next dose: 8:00 AM" accent={C.green} />
        <Stat icon={Heart} label="Last Checkup" value="28 Apr" sub="Dr. Sunita Agarwal" accent={C.gold} />
      </div>

      {/* Appointments + Meds */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20 }}>
        <Card style={{ padding: 22 }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
            <h3 style={{ margin: 0, color: C.navy, fontSize: 15, fontWeight: 700 }}>Upcoming Appointments</h3>
            <Badge label="Scheduled" color="Scheduled" />
          </div>
          {upcoming.length === 0 && <div style={{ color: C.gray400, fontSize: 13, textAlign: "center", padding: 20 }}>No upcoming appointments</div>}
          {upcoming.map(a => {
            return (
              <div key={a.appointment_id} style={{ border: `1px solid ${C.gray100}`, borderRadius: 10, padding: "12px 14px", marginBottom: 10 }}>
                <div style={{ fontWeight: 700, color: C.navy, fontSize: 14 }}>{a.doctor_name}</div>
                <div style={{ color: C.gray600, fontSize: 12, marginTop: 3 }}>{a.doctor_specialization}</div>
                <div style={{ display: "flex", gap: 12, marginTop: 8 }}>
                  <span style={{ color: C.accent, fontSize: 12, display: "flex", alignItems: "center", gap: 4 }}><Calendar size={12} />{a.appointment_date}</span>
                  <span style={{ color: C.gray600, fontSize: 12, display: "flex", alignItems: "center", gap: 4 }}><Clock size={12} />{a.appointment_time}</span>
                </div>
                <div style={{ marginTop: 6, fontSize: 11, color: C.gray400, fontStyle: "italic" }}>{a.notes}</div>
              </div>
            );
          })}
        </Card>

        <Card style={{ padding: 22 }}>
          <h3 style={{ margin: "0 0 16px", color: C.navy, fontSize: 15, fontWeight: 700 }}>Today's Medications</h3>
          {myMeds.map(m => (
            <div key={m.medication_id} style={{ display: "flex", alignItems: "center", gap: 12, padding: "10px 0", borderBottom: `1px solid ${C.gray50}` }}>
              <div style={{ background: "#EFF8FF", borderRadius: 8, padding: 8 }}><Pill size={16} color={C.accent} /></div>
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 600, color: C.navy, fontSize: 13 }}>{m.medicine_name} <span style={{ color: C.gray400, fontWeight: 400 }}>{m.dosage}</span></div>
                <div style={{ color: C.gray600, fontSize: 11, marginTop: 2 }}>{m.frequency} · Reminder: {m.reminder_time}</div>
              </div>
              <div style={{ background: C.green, borderRadius: "50%", width: 22, height: 22, display: "flex", alignItems: "center", justifyContent: "center" }}>
                <Check size={12} color="#fff" />
              </div>
            </div>
          ))}
        </Card>
      </div>
    </div>
  );
};

// ─── APPOINTMENT SCHEDULING ───────────────────────────────────────────────────
const AppointmentScheduler = ({ role, auth }) => {
  const [appointments, setAppointments] = useState([]);
  const [doctorsList, setDoctorsList] = useState(DOCTORS);
  const [showModal, setShowModal] = useState(false);
  const [form, setForm] = useState({ doctor_id: "1", date: new Date().toISOString().split('T')[0], reason: "" });
  const [success, setSuccess] = useState("");

  const fetchAppts = () => {
    fetch(`${API_URL}/appointments`, { headers: { Authorization: `Bearer ${auth.access_token}` } })
      .then(r => r.json())
      .then(data => { if (Array.isArray(data)) setAppointments(data); })
      .catch(console.error);
  };

  useEffect(() => {
    fetchAppts();
    fetch(`${API_URL}/doctors`)
      .then(r => r.json())
      .then(data => { if (Array.isArray(data)) setDoctorsList(data); })
      .catch(console.error);
  }, []);

  const myAppts = appointments;

  const bookedSlots = appointments
    .filter(a => a.doctor_id === parseInt(form.doctor_id) && a.appointment_date === form.date && a.status === "Scheduled")
    .map(a => a.appointment_time);

  const availableSlots = TIME_SLOTS.filter(s => !bookedSlots.includes(s));

  const book = async (time) => {
    const res = await fetch(`${API_URL}/appointments/book`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${auth.access_token}` },
      body: JSON.stringify({ doctor_id: parseInt(form.doctor_id), date: form.date, time: time, reason: form.reason })
    });
    if (res.ok) {
      fetchAppts();
      setShowModal(false);
      setSuccess(`Appointment booked for ${form.date} at ${time}`);
      setTimeout(() => setSuccess(""), 4000);
    }
  };

  const changeStatus = async (id, status) => {
    const res = await fetch(`${API_URL}/appointments/${id}/status`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${auth.access_token}` },
      body: JSON.stringify({ status })
    });
    if (res.ok) fetchAppts();
  };

  const cancel = (id) => changeStatus(id, "Cancelled");
  const complete = (id) => changeStatus(id, "Completed");

  const pageTitle = { patient: "My Appointments", doctor: "Appointment Queue", admin: "All Appointments" }[role];

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div>
          <h2 style={{ margin: 0, color: C.navy, fontSize: 20, fontWeight: 700 }}>{pageTitle}</h2>
          <p style={{ margin: "4px 0 0", color: C.gray600, fontSize: 13 }}>Greedy time-slot scheduling — earliest available slot prioritized</p>
        </div>
        {role === "patient" && <Btn onClick={() => setShowModal(true)} variant="accent"><Plus size={15} /> Book Appointment</Btn>}
      </div>

      {success && (
        <div style={{ background: "#ECFDF5", border: `1px solid ${C.green}`, borderRadius: 8, padding: "12px 16px", color: C.green, fontSize: 13, display: "flex", alignItems: "center", gap: 8 }}>
          <CheckCircle size={16} />{success}
        </div>
      )}

      <Card>
        <div style={{ overflowX: "auto" }}>
          <table style={{ width: "100%", borderCollapse: "collapse" }}>
            <thead>
              <tr style={{ background: C.gray50, borderBottom: `2px solid ${C.gray100}` }}>
                {["ID","Patient","Doctor","Date","Time","Status","Reason","Action"].map(h => (
                  <th key={h} style={{ padding: "12px 16px", textAlign: "left", fontSize: 11, fontWeight: 700, color: C.gray600, letterSpacing: 0.5, whiteSpace: "nowrap" }}>{h.toUpperCase()}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {myAppts.map(a => {
                return (
                  <tr key={a.appointment_id} style={{ borderBottom: `1px solid ${C.gray50}` }}>
                    <td style={{ padding: "12px 16px", fontSize: 12, color: C.gray600 }}>A-{String(a.appointment_id).padStart(3,"0")}</td>
                    <td style={{ padding: "12px 16px", fontSize: 13, fontWeight: 600, color: C.navy }}>{a.patient_name}</td>
                    <td style={{ padding: "12px 16px", fontSize: 13, color: C.navy }}>{a.doctor_name}</td>
                    <td style={{ padding: "12px 16px", fontSize: 13, color: C.gray600 }}>{a.appointment_date}</td>
                    <td style={{ padding: "12px 16px", fontSize: 13, color: C.gray600 }}>{a.appointment_time}</td>
                    <td style={{ padding: "12px 16px" }}><Badge label={a.status} color={a.status} /></td>
                    <td style={{ padding: "12px 16px", fontSize: 12, color: C.gray400, maxWidth: 140, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{a.notes}</td>
                    <td style={{ padding: "12px 16px" }}>
                      {a.status === "Scheduled" && role === "patient" && (
                        <Btn variant="danger" onClick={() => cancel(a.appointment_id)} style={{ padding: "5px 12px", fontSize: 11 }}>
                          <XCircle size={12} /> Cancel
                        </Btn>
                      )}
                      {a.status === "Scheduled" && role === "doctor" && (
                        <Btn variant="accent" onClick={() => complete(a.appointment_id)} style={{ padding: "5px 12px", fontSize: 11 }}>
                          <Check size={12} /> Complete
                        </Btn>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </Card>

      {showModal && (
        <Modal title="Book New Appointment" onClose={() => setShowModal(false)}>
          <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
            <Input label="Select Doctor" value={form.doctor_id} onChange={v => setForm(f => ({ ...f, doctor_id: v }))}
              options={doctorsList.map(d => ({ value: String(d.doctor_id), label: `${d.full_name} — ${d.specialization}` }))} />
            <Input label="Preferred Date" type="date" value={form.date} onChange={v => setForm(f => ({ ...f, date: v }))} />
            <Input label="Reason for Visit" value={form.reason} onChange={v => setForm(f => ({ ...f, reason: v }))} />

            <div>
              <label style={{ fontSize: 12, fontWeight: 700, color: C.gray600, letterSpacing: 0.5, display: "block", marginBottom: 10 }}>AVAILABLE SLOTS (greedy — earliest first)</label>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 8 }}>
                {TIME_SLOTS.map(slot => {
                  const isBooked = bookedSlots.includes(slot);
                  return (
                    <button key={slot} onClick={() => !isBooked && book(slot)} disabled={isBooked}
                      style={{ padding: "9px 0", borderRadius: 8, border: `1.5px solid ${isBooked ? C.gray100 : C.accent}`, background: isBooked ? C.gray50 : "#EFF8FF", color: isBooked ? C.gray400 : C.accent, fontSize: 12, fontWeight: 600, cursor: isBooked ? "not-allowed" : "pointer", position: "relative" }}>
                      {slot}
                      {isBooked && <div style={{ position: "absolute", top: 2, right: 2, width: 6, height: 6, background: C.red, borderRadius: "50%" }} />}
                    </button>
                  );
                })}
              </div>
              <div style={{ display: "flex", gap: 14, marginTop: 10, fontSize: 11, color: C.gray600 }}>
                <span style={{ display: "flex", alignItems: "center", gap: 4 }}><span style={{ width: 8, height: 8, background: C.accent, borderRadius: 2 }} />Available</span>
                <span style={{ display: "flex", alignItems: "center", gap: 4 }}><span style={{ width: 8, height: 8, background: C.gray100, borderRadius: 2 }} />Booked</span>
              </div>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
};

// ─── HEALTH RECORDS ───────────────────────────────────────────────────────────
const HealthRecords = ({ role }) => {
  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState(null);

  const records = HEALTH_RECORDS.filter(r =>
    r.diagnosis.toLowerCase().includes(search.toLowerCase()) ||
    r.prescription.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div>
          <h2 style={{ margin: 0, color: C.navy, fontSize: 20, fontWeight: 700 }}>Electronic Health Records</h2>
          <p style={{ margin: "4px 0 0", color: C.gray600, fontSize: 13 }}>Chronological medical history, prescriptions & lab reports</p>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 8, background: C.gray50, border: `1px solid ${C.gray100}`, borderRadius: 8, padding: "8px 12px" }}>
          <Search size={14} color={C.gray400} />
          <input placeholder="Search diagnosis..." value={search} onChange={e => setSearch(e.target.value)}
            style={{ border: "none", background: "transparent", fontSize: 13, color: C.navy, outline: "none", width: 180 }} />
        </div>
      </div>

      <div style={{ display: "grid", gap: 16 }}>
        {records.map(r => {
          const pat = PATIENTS.find(p => p.patient_id === r.patient_id);
          const doc = DOCTORS.find(d => d.doctor_id === r.doctor_id);
          return (
            <Card key={r.record_id} style={{ padding: 22, cursor: "pointer", transition: "box-shadow 0.15s", border: selected === r.record_id ? `2px solid ${C.accent}` : `1px solid ${C.gray100}` }}
              onClick={() => setSelected(selected === r.record_id ? null : r.record_id)}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
                <div style={{ display: "flex", gap: 14, alignItems: "flex-start" }}>
                  <div style={{ background: "#EFF8FF", borderRadius: 10, padding: "10px 12px", flexShrink: 0 }}>
                    <FileText size={20} color={C.accent} />
                  </div>
                  <div>
                    <div style={{ fontWeight: 700, color: C.navy, fontSize: 15 }}>{r.diagnosis}</div>
                    <div style={{ color: C.gray600, fontSize: 12, marginTop: 4 }}>
                      {pat?.full_name} · Treated by {doc?.full_name}
                    </div>
                    <div style={{ display: "flex", gap: 14, marginTop: 8 }}>
                      <span style={{ color: C.accent, fontSize: 12, display: "flex", alignItems: "center", gap: 4 }}><Calendar size={12} />{r.visit_date}</span>
                      {r.follow_up_date && <span style={{ color: C.amber, fontSize: 12, display: "flex", alignItems: "center", gap: 4 }}><Clock size={12} />Follow-up: {r.follow_up_date}</span>}
                    </div>
                  </div>
                </div>
                <ChevronDown size={18} color={C.gray400} style={{ transform: selected === r.record_id ? "rotate(180deg)" : "none", transition: "transform 0.2s" }} />
              </div>

              {selected === r.record_id && (
                <div style={{ marginTop: 18, paddingTop: 18, borderTop: `1px solid ${C.gray100}`, display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
                  <div>
                    <div style={{ fontSize: 11, fontWeight: 700, color: C.gray400, letterSpacing: 0.5, marginBottom: 6 }}>PRESCRIPTION</div>
                    <div style={{ background: C.gray50, borderRadius: 8, padding: "10px 12px", fontSize: 13, color: C.navy, lineHeight: 1.7 }}>{r.prescription}</div>
                  </div>
                  <div>
                    <div style={{ fontSize: 11, fontWeight: 700, color: C.gray400, letterSpacing: 0.5, marginBottom: 6 }}>LAB REPORTS</div>
                    <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
                      {r.lab_reports.split(", ").map(lab => (
                        <span key={lab} style={{ background: "#EFF8FF", color: C.accent, border: `1px solid ${C.accent}33`, borderRadius: 6, padding: "4px 10px", fontSize: 12, fontWeight: 600 }}>{lab}</span>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </Card>
          );
        })}
      </div>
    </div>
  );
};

// ─── MEDICATIONS ──────────────────────────────────────────────────────────────
const MedicationManager = ({ auth }) => {
  const [meds, setMeds] = useState([]);
  const [showAdd, setShowAdd] = useState(false);
  const [form, setForm] = useState({ medicine_name: "", dosage: "", frequency: "Daily", start_date: new Date().toISOString().split('T')[0], end_date: "", reminder_time: "08:00" });

  const fetchMeds = () => {
    fetch(`${API_URL}/medications`, { headers: { Authorization: `Bearer ${auth.access_token}` } })
      .then(r => r.json())
      .then(data => { if (Array.isArray(data)) setMeds(data); })
      .catch(console.error);
  };
  useEffect(() => { fetchMeds(); }, []);

  const add = async () => {
    const res = await fetch(`${API_URL}/medications`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${auth.access_token}` },
      body: JSON.stringify(form)
    });
    if (res.ok) {
      fetchMeds();
      setShowAdd(false);
      setForm({ medicine_name: "", dosage: "", frequency: "Daily", start_date: new Date().toISOString().split('T')[0], end_date: "", reminder_time: "08:00" });
    }
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div>
          <h2 style={{ margin: 0, color: C.navy, fontSize: 20, fontWeight: 700 }}>Medication Manager</h2>
          <p style={{ margin: "4px 0 0", color: C.gray600, fontSize: 13 }}>Dosage tracking, schedule & automated reminders</p>
        </div>
        <Btn onClick={() => setShowAdd(true)} variant="accent"><Plus size={15} /> Add Medication</Btn>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(300px, 1fr))", gap: 16 }}>
        {meds.map(m => {
          const isActive = !m.end_date || new Date(m.end_date) >= new Date("2026-05-10");
          return (
            <Card key={m.medication_id} style={{ padding: 22 }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 14 }}>
                <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
                  <div style={{ background: isActive ? "#EFF8FF" : C.gray50, borderRadius: 10, padding: 10 }}>
                    <Pill size={20} color={isActive ? C.accent : C.gray400} />
                  </div>
                  <div>
                    <div style={{ fontWeight: 700, color: C.navy, fontSize: 15 }}>{m.medicine_name}</div>
                    <div style={{ color: C.gray600, fontSize: 12 }}>{m.dosage}</div>
                  </div>
                </div>
                <Badge label={isActive ? "Active" : "Inactive"} color={isActive ? "Active" : "Inactive"} />
              </div>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
                {[["Frequency", m.frequency], ["Reminder", m.reminder_time], ["Start", m.start_date], ["End", m.end_date || "Ongoing"]].map(([k, v]) => (
                  <div key={k}>
                    <div style={{ fontSize: 10, fontWeight: 700, color: C.gray400, letterSpacing: 0.5 }}>{k.toUpperCase()}</div>
                    <div style={{ fontSize: 13, color: C.navy, fontWeight: 600, marginTop: 2 }}>{v}</div>
                  </div>
                ))}
              </div>
              {isActive && (
                <div style={{ marginTop: 14, background: "#ECFDF5", borderRadius: 8, padding: "8px 12px", display: "flex", alignItems: "center", gap: 8 }}>
                  <Bell size={13} color={C.green} />
                  <span style={{ fontSize: 12, color: C.green, fontWeight: 600 }}>Reminder set for {m.reminder_time} daily</span>
                </div>
              )}
            </Card>
          );
        })}
      </div>

      {showAdd && (
        <Modal title="Add New Medication" onClose={() => setShowAdd(false)}>
          <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
            <Input label="Medicine Name" value={form.medicine_name} onChange={v => setForm(f => ({ ...f, medicine_name: v }))} />
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
              <Input label="Dosage" value={form.dosage} onChange={v => setForm(f => ({ ...f, dosage: v }))} />
              <Input label="Frequency" value={form.frequency} onChange={v => setForm(f => ({ ...f, frequency: v }))}
                options={["Daily", "Twice Daily", "3x Daily", "Weekly", "As needed"]} />
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
              <Input label="Start Date" type="date" value={form.start_date} onChange={v => setForm(f => ({ ...f, start_date: v }))} />
              <Input label="End Date" type="date" value={form.end_date} onChange={v => setForm(f => ({ ...f, end_date: v }))} />
            </div>
            <Input label="Reminder Time" type="time" value={form.reminder_time} onChange={v => setForm(f => ({ ...f, reminder_time: v }))} />
            <Btn onClick={add} disabled={!form.medicine_name || !form.dosage} style={{ justifyContent: "center" }}>
              <Plus size={15} /> Add Medication
            </Btn>
          </div>
        </Modal>
      )}
    </div>
  );
};

// ─── MESSAGES ─────────────────────────────────────────────────────────────────
const Messages = () => {
  const [messages, setMessages] = useState([
    { id: 1, from: "Dr. Rakesh Mehta", time: "09:30", text: "Please ensure you take your Amlodipine before breakfast and avoid salty food.", fromDoc: true },
    { id: 2, from: "Arjun Sharma", time: "10:15", text: "Understood, Doctor. Should I continue the medication for another month?", fromDoc: false },
    { id: 3, from: "Dr. Rakesh Mehta", time: "10:22", text: "Yes, please continue. Also get a BP check done before your next appointment.", fromDoc: true },
  ]);
  const [newMsg, setNewMsg] = useState("");

  const send = () => {
    if (!newMsg.trim()) return;
    setMessages(prev => [...prev, { id: prev.length + 1, from: "Arjun Sharma", time: new Date().toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit" }), text: newMsg, fromDoc: false }]);
    setNewMsg("");
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
      <h2 style={{ margin: 0, color: C.navy, fontSize: 20, fontWeight: 700 }}>Secure Messaging</h2>
      <Card style={{ padding: 0, overflow: "hidden" }}>
        <div style={{ background: C.navy, padding: "16px 20px", display: "flex", alignItems: "center", gap: 12 }}>
          <div style={{ width: 36, height: 36, borderRadius: "50%", background: C.accent, display: "flex", alignItems: "center", justifyContent: "center" }}>
            <Stethoscope size={16} color="#fff" />
          </div>
          <div>
            <div style={{ color: "#fff", fontWeight: 700, fontSize: 14 }}>Dr. Rakesh Mehta</div>
            <div style={{ color: "rgba(255,255,255,0.5)", fontSize: 11 }}>Cardiology · Online</div>
          </div>
          <div style={{ marginLeft: "auto", width: 8, height: 8, background: C.green, borderRadius: "50%" }} />
        </div>
        <div style={{ padding: 20, minHeight: 260, display: "flex", flexDirection: "column", gap: 12 }}>
          {messages.map(m => (
            <div key={m.id} style={{ display: "flex", justifyContent: m.fromDoc ? "flex-start" : "flex-end" }}>
              <div style={{ maxWidth: "72%", background: m.fromDoc ? C.gray50 : C.navy, borderRadius: m.fromDoc ? "4px 14px 14px 14px" : "14px 4px 14px 14px", padding: "10px 14px" }}>
                <div style={{ fontSize: 13, color: m.fromDoc ? C.navy : "#fff", lineHeight: 1.5 }}>{m.text}</div>
                <div style={{ fontSize: 10, color: m.fromDoc ? C.gray400 : "rgba(255,255,255,0.5)", marginTop: 4, textAlign: "right" }}>{m.time}</div>
              </div>
            </div>
          ))}
        </div>
        <div style={{ padding: "12px 16px", borderTop: `1px solid ${C.gray100}`, display: "flex", gap: 10 }}>
          <input value={newMsg} onChange={e => setNewMsg(e.target.value)} onKeyDown={e => e.key === "Enter" && send()}
            placeholder="Type a message..."
            style={{ flex: 1, border: `1.5px solid ${C.gray100}`, borderRadius: 24, padding: "10px 16px", fontSize: 13, outline: "none", color: C.navy }} />
          <Btn onClick={send} variant="accent" style={{ borderRadius: 24, padding: "10px 18px" }}>Send</Btn>
        </div>
      </Card>
    </div>
  );
};

// ─── DOCTOR DASHBOARD ─────────────────────────────────────────────────────────
const DoctorDashboard = ({ auth }) => {
  const doc = auth.user_info || {};
  const [myAppts, setMyAppts] = useState([]);

  useEffect(() => {
    fetch(`${API_URL}/appointments`, { headers: { Authorization: `Bearer ${auth.access_token}` } })
      .then(r => r.json())
      .then(data => { if (Array.isArray(data)) setMyAppts(data); })
      .catch(console.error);
  }, [auth.access_token]);

  const todayStr = new Date().toISOString().split('T')[0];
  const today = myAppts.filter(a => a.appointment_date === todayStr);

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 24 }}>
      <div style={{ background: `linear-gradient(120deg, ${C.navy}, ${C.navyLight})`, borderRadius: 14, padding: "24px 28px", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div>
          <div style={{ color: "rgba(255,255,255,0.55)", fontSize: 12, letterSpacing: 0.5 }}>DOCTOR PORTAL</div>
          <div style={{ color: "#fff", fontSize: 22, fontWeight: 700, marginTop: 4 }}>{doc.full_name}</div>
          <div style={{ color: "rgba(255,255,255,0.55)", fontSize: 12, marginTop: 6 }}>{doc.specialization}</div>
        </div>
        <div style={{ textAlign: "right" }}>
          <div style={{ color: "rgba(255,255,255,0.5)", fontSize: 11 }}>Doctor ID</div>
          <div style={{ color: C.gold, fontWeight: 700 }}>D-{String(auth.entity_id).padStart(4,"0")}</div>
        </div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(170px, 1fr))", gap: 16 }}>
        <Stat icon={Calendar} label="Today's Appointments" value={today.length} accent={C.accent} />
        <Stat icon={Users} label="Total Appointments" value={myAppts.length} accent={C.navyLight} />
        <Stat icon={CheckCircle} label="Completed" value={myAppts.filter(a => a.status === "Completed").length} accent={C.green} />
        <Stat icon={Clock} label="Pending" value={myAppts.filter(a => a.status === "Scheduled").length} accent={C.amber} />
      </div>

      <Card style={{ padding: 22 }}>
        <h3 style={{ margin: "0 0 16px", color: C.navy, fontSize: 15, fontWeight: 700 }}>Patient Queue</h3>
        {myAppts.filter(a => a.status === "Scheduled").map((a, i) => {
          return (
            <div key={a.appointment_id} style={{ display: "flex", alignItems: "center", gap: 14, padding: "12px 0", borderBottom: `1px solid ${C.gray50}` }}>
              <div style={{ width: 32, height: 32, borderRadius: "50%", background: C.navy, display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontSize: 13, fontWeight: 700, flexShrink: 0 }}>{i + 1}</div>
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 600, color: C.navy, fontSize: 14 }}>{a.patient_name}</div>
                <div style={{ color: C.gray600, fontSize: 12, marginTop: 2 }}>{a.notes} · {a.appointment_time}</div>
              </div>
              <div style={{ display: "flex", gap: 8 }}>
                <Btn variant="outline" style={{ padding: "5px 12px", fontSize: 11 }}><Eye size={12} /> View</Btn>
                <Btn variant="accent" style={{ padding: "5px 12px", fontSize: 11 }}><Edit size={12} /> Consult</Btn>
              </div>
            </div>
          );
        })}
      </Card>
    </div>
  );
};

// ─── ADMIN DASHBOARD ──────────────────────────────────────────────────────────
const AdminDashboard = ({ auth }) => {
  const [stats, setStats] = useState({ users: 0, patients: 0, doctors: 0, appointments: 0 });

  useEffect(() => {
    fetch(`${API_URL}/admin/stats`, { headers: { Authorization: `Bearer ${auth.access_token}` } })
      .then(r => r.json())
      .then(data => { if (data && !data.error) setStats(data); })
      .catch(console.error);
  }, [auth.access_token]);

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 24 }}>
      <div style={{ background: `linear-gradient(120deg, ${C.gray800}, ${C.navy})`, borderRadius: 14, padding: "24px 28px" }}>
        <div style={{ color: "rgba(255,255,255,0.55)", fontSize: 12, letterSpacing: 0.5 }}>SYSTEM ADMINISTRATION</div>
        <div style={{ color: "#fff", fontSize: 22, fontWeight: 700, marginTop: 4 }}>Admin Control Panel</div>
        <div style={{ color: "rgba(255,255,255,0.45)", fontSize: 12, marginTop: 6 }}>JECRC University · Integrated Healthcare Management System</div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(170px, 1fr))", gap: 16 }}>
        <Stat icon={Users} label="Total Users" value={stats.users} accent={C.navy} />
        <Stat icon={Stethoscope} label="Doctors" value={stats.doctors} accent={C.accent} />
        <Stat icon={User} label="Patients" value={stats.patients} accent={C.navyLight} />
        <Stat icon={Calendar} label="Appointments" value={stats.appointments} accent={C.green} />
        <Stat icon={TrendingUp} label="Pass Rate" value="97.3%" sub="150 test cases" accent={C.gold} />
        <Stat icon={Zap} label="System Uptime" value="99.8%" sub="Last 30 days" accent={C.green} />
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20 }}>
        <Card style={{ padding: 22 }}>
          <h3 style={{ margin: "0 0 16px", color: C.navy, fontSize: 15, fontWeight: 700 }}>Module Test Summary</h3>
          {[
            { module: "User Authentication", passed: 17, total: 18 },
            { module: "Patient Management", passed: 22, total: 22 },
            { module: "Appointment Scheduling", passed: 24, total: 25 },
            { module: "Health Records", passed: 20, total: 20 },
            { module: "Medication Manager", passed: 15, total: 15 },
            { module: "Communication", passed: 11, total: 12 },
          ].map(({ module, passed, total }) => {
            const pct = Math.round((passed / total) * 100);
            return (
              <div key={module} style={{ marginBottom: 12 }}>
                <div style={{ display: "flex", justifyContent: "space-between", fontSize: 12, marginBottom: 4 }}>
                  <span style={{ color: C.navy, fontWeight: 600 }}>{module}</span>
                  <span style={{ color: pct === 100 ? C.green : C.amber, fontWeight: 700 }}>{passed}/{total}</span>
                </div>
                <div style={{ background: C.gray100, borderRadius: 4, height: 6 }}>
                  <div style={{ width: `${pct}%`, background: pct === 100 ? C.green : C.amber, borderRadius: 4, height: "100%", transition: "width 0.5s" }} />
                </div>
              </div>
            );
          })}
        </Card>

        <Card style={{ padding: 22 }}>
          <h3 style={{ margin: "0 0 16px", color: C.navy, fontSize: 15, fontWeight: 700 }}>Performance Benchmarks</h3>
          {[
            { users: 1, avg: 45, err: "0%" },
            { users: 10, avg: 89, err: "0%" },
            { users: 25, avg: 156, err: "0%" },
            { users: 50, avg: 312, err: "0.2%" },
            { users: 100, avg: 687, err: "1.4%" },
            { users: 200, avg: 1456, err: "3.2%" },
          ].map(({ users, avg, err }) => (
            <div key={users} style={{ display: "flex", justifyContent: "space-between", padding: "8px 0", borderBottom: `1px solid ${C.gray50}`, fontSize: 12 }}>
              <span style={{ color: C.gray600 }}>{users} concurrent users</span>
              <span style={{ color: C.navy, fontWeight: 600 }}>{avg}ms avg</span>
              <span style={{ color: parseFloat(err) > 1 ? C.red : C.green, fontWeight: 600 }}>{err} errors</span>
            </div>
          ))}
        </Card>
      </div>
    </div>
  );
};

// ─── USER MANAGEMENT (Admin) ──────────────────────────────────────────────────
const UserManagement = ({ auth }) => {
  const [allUsers, setAllUsers] = useState([]);

  useEffect(() => {
    fetch(`${API_URL}/users`, { headers: { Authorization: `Bearer ${auth.access_token}` } })
      .then(r => r.json())
      .then(data => { if (Array.isArray(data)) setAllUsers(data); })
      .catch(console.error);
  }, [auth.access_token]);

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div>
          <h2 style={{ margin: 0, color: C.navy, fontSize: 20, fontWeight: 700 }}>User Management</h2>
          <p style={{ margin: "4px 0 0", color: C.gray600, fontSize: 13 }}>Role-based access control · JWT Authentication</p>
        </div>
        <Btn variant="accent"><Plus size={15} /> Add User</Btn>
      </div>
      <Card>
        <table style={{ width: "100%", borderCollapse: "collapse" }}>
          <thead>
            <tr style={{ background: C.gray50, borderBottom: `2px solid ${C.gray100}` }}>
              {["ID","Username","Email","Role","Status","Actions"].map(h => (
                <th key={h} style={{ padding: "12px 16px", textAlign: "left", fontSize: 11, fontWeight: 700, color: C.gray600, letterSpacing: 0.5 }}>{h.toUpperCase()}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {allUsers.map(u => (
              <tr key={u.user_id} style={{ borderBottom: `1px solid ${C.gray50}` }}>
                <td style={{ padding: "12px 16px", fontSize: 12, color: C.gray600 }}>{u.user_id}</td>
                <td style={{ padding: "12px 16px", fontSize: 13, fontWeight: 600, color: C.navy }}>{u.username}</td>
                <td style={{ padding: "12px 16px", fontSize: 13, color: C.gray600 }}>{u.email}</td>
                <td style={{ padding: "12px 16px" }}>
                  <span style={{ background: u.role === "admin" ? "#FEF3C7" : u.role === "doctor" ? "#EFF8FF" : "#F0FDF4", color: u.role === "admin" ? C.gold : u.role === "doctor" ? C.accent : C.green, borderRadius: 6, padding: "3px 10px", fontSize: 11, fontWeight: 700, textTransform: "capitalize" }}>{u.role}</span>
                </td>
                <td style={{ padding: "12px 16px" }}><Badge label={u.is_active ? "Active" : "Inactive"} color={u.is_active ? "Active" : "Inactive"} /></td>
                <td style={{ padding: "12px 16px", display: "flex", gap: 6 }}>
                  <Btn variant="ghost" style={{ padding: "5px 10px", fontSize: 11 }}><Edit size={12} /></Btn>
                  <Btn variant="danger" style={{ padding: "5px 10px", fontSize: 11 }}><X size={12} /></Btn>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </div>
  );
};

// ─── DOCTOR PATIENTS VIEW ─────────────────────────────────────────────────────
const DoctorPatients = ({ auth }) => {
  const [patientsList, setPatientsList] = useState([]);

  useEffect(() => {
    fetch(`${API_URL}/patients`, { headers: { Authorization: `Bearer ${auth.access_token}` } })
      .then(r => r.json())
      .then(data => { if (Array.isArray(data)) setPatientsList(data); })
      .catch(console.error);
  }, [auth.access_token]);

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
      <h2 style={{ margin: 0, color: C.navy, fontSize: 20, fontWeight: 700 }}>My Patients</h2>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: 16 }}>
        {patientsList.map(p => (
          <Card key={p.patient_id} style={{ padding: 22 }}>
            <div style={{ display: "flex", gap: 14, alignItems: "center", marginBottom: 14 }}>
              <div style={{ width: 44, height: 44, borderRadius: "50%", background: `linear-gradient(135deg, ${C.navy}, ${C.accent})`, display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontWeight: 700, fontSize: 16 }}>{p.full_name?.charAt(0)}</div>
              <div>
                <div style={{ fontWeight: 700, color: C.navy, fontSize: 15 }}>{p.full_name}</div>
                <div style={{ color: C.gray600, fontSize: 12 }}>DOB: {p.date_of_birth}</div>
              </div>
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
              {[["Blood Group", p.blood_group], ["Gender", p.gender], ["Phone", p.phone]].map(([k, v]) => (
                <div key={k}>
                  <div style={{ fontSize: 10, fontWeight: 700, color: C.gray400, letterSpacing: 0.5 }}>{k.toUpperCase()}</div>
                  <div style={{ fontSize: 13, color: C.navy, fontWeight: 600, marginTop: 2 }}>{v || "—"}</div>
                </div>
              ))}
            </div>
            <div style={{ marginTop: 14, display: "flex", gap: 8 }}>
              <Btn variant="outline" style={{ flex: 1, justifyContent: "center", fontSize: 12 }}><Eye size={13} /> Records</Btn>
              <Btn variant="accent" style={{ flex: 1, justifyContent: "center", fontSize: 12 }}><Edit size={13} /> Update</Btn>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
};

// ─── APP SHELL ────────────────────────────────────────────────────────────────
const PAGE_TITLES = {
  dashboard: "Dashboard", appointments: "Appointments", records: "Health Records",
  medications: "Medications", messages: "Messages", patients: "Patients",
  users: "User Management", analytics: "Analytics", settings: "System Settings",
};

export default function App() {
  const [auth, setAuth] = useState(null);
  const [active, setActive] = useState("dashboard");

  const login = (data) => { setAuth(data); setActive("dashboard"); };
  const logout = () => { setAuth(null); setActive("dashboard"); };

  if (!auth) return <Login onLogin={login} />;

  const { role, user_info } = auth;
  const userName = user_info?.full_name || (role === "patient" ? "Patient" : role === "doctor" ? "Doctor" : "Admin");

  const renderPage = () => {
    if (role === "patient") {
      if (active === "dashboard") return <PatientDashboard auth={auth} />;
      if (active === "appointments") return <AppointmentScheduler role="patient" auth={auth} />;
      if (active === "records") return <HealthRecords role="patient" />;
      if (active === "medications") return <MedicationManager auth={auth} />;
      if (active === "messages") return <Messages />;
    }
    if (role === "doctor") {
      if (active === "dashboard") return <DoctorDashboard auth={auth} />;
      if (active === "patients") return <DoctorPatients auth={auth} />;
      if (active === "appointments") return <AppointmentScheduler role="doctor" auth={auth} />;
      if (active === "records") return <HealthRecords role="doctor" />;
    }
    if (role === "admin") {
      if (active === "dashboard") return <AdminDashboard auth={auth} />;
      if (active === "users") return <UserManagement auth={auth} />;
      if (active === "appointments") return <AppointmentScheduler role="admin" auth={auth} />;
      if (active === "analytics") return (
        <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
          <h2 style={{ margin: 0, color: C.navy, fontSize: 20, fontWeight: 700 }}>System Analytics</h2>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(170px, 1fr))", gap: 16 }}>
            <Stat icon={BarChart2} label="Test Pass Rate" value="97.3%" accent={C.green} />
            <Stat icon={Activity} label="Avg Response (50 users)" value="312ms" accent={C.accent} />
            <Stat icon={Database} label="DB Tables" value="6" sub="3NF Normalized" accent={C.navyLight} />
            <Stat icon={Shield} label="Security Score" value="A+" sub="JWT + bcrypt" accent={C.navy} />
          </div>
        </div>
      );
      if (active === "settings") return (
        <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
          <h2 style={{ margin: 0, color: C.navy, fontSize: 20, fontWeight: 700 }}>System Configuration</h2>
          <Card style={{ padding: 28 }}>
            {[["Backend Framework", "Python (Flask 2.0)"], ["Database", "MySQL 8.0 – 3NF Normalized"], ["Authentication", "JWT + bcrypt (cost factor 12)"], ["Architecture", "Three-Tier Client-Server"], ["Deployment", "XAMPP / Apache (Local)"], ["Session Management", "Stateless JWT Tokens"], ["API Style", "RESTful Endpoints"]].map(([k, v]) => (
              <div key={k} style={{ display: "flex", justifyContent: "space-between", padding: "12px 0", borderBottom: `1px solid ${C.gray50}`, fontSize: 13 }}>
                <span style={{ color: C.gray600 }}>{k}</span>
                <span style={{ color: C.navy, fontWeight: 600 }}>{v}</span>
              </div>
            ))}
          </Card>
        </div>
      );
    }
    return <div style={{ color: C.gray400, padding: 40, textAlign: "center" }}>Select a section from the sidebar</div>;
  };

  return (
    <div style={{ display: "flex", minHeight: "100vh", background: C.gray50, fontFamily: "'Segoe UI', system-ui, sans-serif" }}>
      <Sidebar role={role} active={active} setActive={setActive} onLogout={logout} />
      <div style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden" }}>
        <TopBar title={PAGE_TITLES[active] || "Medi Vault HMS"} userName={userName} />
        <main style={{ flex: 1, overflowY: "auto", padding: 28 }}>
          {renderPage()}
        </main>
      </div>
    </div>
  );
}
