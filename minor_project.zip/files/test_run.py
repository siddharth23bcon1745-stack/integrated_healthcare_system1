import sys
import cryptography
print(f"Python Path: {sys.executable}")
print(f"Cryptography Version: {cryptography.__version__}")