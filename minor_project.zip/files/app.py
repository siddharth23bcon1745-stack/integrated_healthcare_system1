"""
Integrated Healthcare Management System — Flask REST API
Dynamic Backend with RBAC, CORS, and Relational Database

Install dependencies:
    pip install flask flask-cors flask-sqlalchemy flask-jwt-extended bcrypt pymysql python-dotenv
"""

import os
from datetime import datetime, timedelta, date, time as dtime
from dotenv import load_dotenv

from flask import Flask, request, jsonify
from flask_cors import CORS
from flask_sqlalchemy import SQLAlchemy
from flask_jwt_extended import (
    JWTManager, create_access_token,
    jwt_required, get_jwt_identity,
    get_jwt
)
import bcrypt

import random
import smtplib
from email.message import EmailMessage

# ─── Configuration ─────────────────────────────────────────────────────────────
load_dotenv()

app = Flask(__name__)
# Enable CORS so the React frontend can communicate with the Flask API
CORS(app, resources={r"/api/*": {"origins": "*"}})
CORS(app)

app.config.update(
    # Fallback to SQLite if MySQL isn't configured for easy local testing
    SQLALCHEMY_DATABASE_URI=os.getenv("DATABASE_URL", "sqlite:///medivault.db"),
    SQLALCHEMY_TRACK_MODIFICATIONS=False,
    JWT_SECRET_KEY=os.getenv("JWT_SECRET", "super-secret-medivault-key"),
    JWT_ACCESS_TOKEN_EXPIRES=timedelta(hours=12),
)

db = SQLAlchemy(app)
jwt = JWTManager(app)

# ─── Database Models ─────────────────────────────────────────────────────────

class User(db.Model):
    __tablename__ = 'users'
    user_id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    email = db.Column(db.String(100), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.Enum('patient', 'doctor', 'admin'), nullable=False)
    is_active = db.Column(db.Boolean, default=True)

class Patient(db.Model):
    __tablename__ = 'patients'
    patient_id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.user_id'), nullable=False)
    full_name = db.Column(db.String(100), nullable=False)
    date_of_birth = db.Column(db.Date, nullable=False)
    blood_group = db.Column(db.String(5))
    phone = db.Column(db.String(15))
    
    user = db.relationship('User', backref=db.backref('patient_profile', uselist=False))

class Doctor(db.Model):
    __tablename__ = 'doctors'
    doctor_id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.user_id'), nullable=False)
    
    # --- THESE WERE THE MISSING FIELDS! ---
    full_name = db.Column(db.String(100), nullable=False)
    specialization = db.Column(db.String(100), nullable=False)
    qualification = db.Column(db.String(200), nullable=False)
    registration_no = db.Column(db.String(50), unique=True)
    consultation_fee = db.Column(db.Numeric(10, 2))
    # --------------------------------------
    
    user = db.relationship('User', backref=db.backref('doctor_profile', uselist=False))

class Appointment(db.Model):
    __tablename__ = 'appointments'
    appointment_id = db.Column(db.Integer, primary_key=True)
    patient_id = db.Column(db.Integer, db.ForeignKey('patients.patient_id'), nullable=False)
    doctor_id = db.Column(db.Integer, db.ForeignKey('doctors.doctor_id'), nullable=False)
    appointment_date = db.Column(db.Date, nullable=False)
    appointment_time = db.Column(db.Time, nullable=False)
    status = db.Column(db.Enum('Scheduled', 'Completed', 'Cancelled'), default='Scheduled')
    notes = db.Column(db.Text)

class Medication(db.Model):
    __tablename__ = 'medications'
    medication_id = db.Column(db.Integer, primary_key=True)
    patient_id = db.Column(db.Integer, db.ForeignKey('patients.patient_id'), nullable=False)
    medicine_name = db.Column(db.String(100), nullable=False)
    dosage = db.Column(db.String(50))
    frequency = db.Column(db.String(50))
    start_date = db.Column(db.Date)
    end_date = db.Column(db.Date)
    reminder_time = db.Column(db.Time)

class HealthRecord(db.Model):
    __tablename__ = 'health_records'
    record_id = db.Column(db.Integer, primary_key=True)
    patient_id = db.Column(db.Integer, db.ForeignKey('patients.patient_id'), nullable=False)
    doctor_id = db.Column(db.Integer, db.ForeignKey('doctors.doctor_id'), nullable=False)
    visit_date = db.Column(db.Date, nullable=False)
    diagnosis = db.Column(db.Text)
    prescription = db.Column(db.Text)
    lab_reports = db.Column(db.String(500))
    follow_up_date = db.Column(db.Date)


@app.route('/api/auth/request-code', methods=['POST'])
def request_code():
    data = request.json
    email = data.get('email')
    
    if not email:
        return jsonify({"error": "Email is required"}), 400

    # 1. Generate a 6-digit code
    code = str(random.randint(100000, 999999))
    
    # 2. Calculate expiration time (5 minutes from now)
    expires = datetime.now() + timedelta(minutes=5)

    try:
        # 3. Save directly to MySQL instead of memory
        new_otp = OTPCode(email=email, code=code, expires_at=expires)
        db.session.add(new_otp)
        db.session.commit()

        # PRINT TO TERMINAL (For local testing)
        print(f"\n{'='*40}")
        print(f"🔐 LOGIN CODE FOR {email}: {code}")
        print(f"⏳ Expires at: {expires.strftime('%I:%M %p')}")
        print(f"{'='*40}\n")

        return jsonify({"message": "Secure code generated and saved."}), 200

    except Exception as e:
        db.session.rollback()
        return jsonify({"error": str(e)}), 500



@app.route('/api/auth/verify-code', methods=['POST'])
def verify_code():
    data = request.json
    email = data.get('email')
    code = data.get('code')

    # 1. Query the database for the code
    otp_record = OTPCode.query.filter_by(email=email, code=code).order_by(OTPCode.created_at.desc()).first()

    if not otp_record:
        return jsonify({"error": "Invalid login code."}), 401
    
    if datetime.now() > otp_record.expires_at:
        db.session.delete(otp_record) 
        db.session.commit()
        return jsonify({"error": "This code has expired. Please request a new one."}), 401

    # Clean up the code so it can't be reused
    db.session.delete(otp_record)
    db.session.commit()

    # 2. Check if the user exists in the system
    user = User.query.filter_by(email=email).first()
    
    # --- NEW AUTO-REGISTRATION LOGIC ---
    if not user:
        # Prevent unauthorized people from auto-registering as Staff
        if email.endswith("@healthcare.com") or email.endswith("@medivault.com") or email.endswith("@hospital.com"):
            return jsonify({"error": "Staff accounts must be provisioned by a System Administrator."}), 403
        
        # If it's a normal email (like Gmail), Auto-Register them as a Patient!
        user = User(
            username=email.split('@')[0] + str(int(datetime.now().timestamp())),
            email=email,
            password_hash="passwordless_otp", # Not needed anymore!
            role="patient"
        )
        db.session.add(user)
        db.session.commit()

        # Generate a blank Patient profile
        new_patient = Patient(
            user_id=user.user_id, 
            full_name="New Patient", 
            date_of_birth=date(2000, 1, 1), 
            phone="N/A", 
            gender="Other"
        )
        db.session.add(new_patient)
        db.session.commit()
    # -----------------------------------

    if not user.is_active:
        return jsonify({"error": "Account is suspended."}), 403

    # 3. Generate JWT Token
    access_token = create_access_token(identity=str(user.user_id))
    
    # 4. Build User Info
    entity_id = user.user_id
    user_info = {"full_name": "Unknown", "email": user.email}
    
    if user.role == 'patient':
        patient = Patient.query.filter_by(user_id=user.user_id).first()
        if patient: 
            entity_id = patient.patient_id
            user_info["full_name"] = patient.full_name
            user_info["blood_group"] = patient.blood_group
    elif user.role == 'doctor':
        doctor = Doctor.query.filter_by(user_id=user.user_id).first()
        if doctor: 
            entity_id = doctor.doctor_id
            user_info["full_name"] = doctor.full_name
            user_info["specialization"] = doctor.specialization
    elif user.role == 'admin':
        user_info["full_name"] = "Administrator"

    return jsonify({
        "access_token": access_token,
        "role": user.role,
        "entity_id": entity_id,
        "user_info": user_info
    }), 200

# ─── Helper Functions ────────────────────────────────────────────────────────

def hash_password(password):
    return bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')

def check_password(password, hashed):
    return bcrypt.checkpw(password.encode('utf-8'), hashed.encode('utf-8'))

# Add role data to JWT claims
@jwt.additional_claims_loader
def add_claims_to_access_token(identity):
    user = User.query.get(identity)
    return {"role": user.role if user else None}


# ─── API Routes ──────────────────────────────────────────────────────────────

@app.route('/api/admin/users', methods=['GET'])
@jwt_required()
def get_all_users():
    claims = get_jwt()
    if claims.get("role") != 'admin':
        return jsonify({"error": "Unauthorized"}), 403

    users = User.query.all()
    user_list = []
    
    for u in users:
        user_list.append({
            "id": u.user_id,
            "email": u.email,
            "role": u.role,
            "status": "Active" if u.is_active else "Suspended",
            "info": {
                "full_name": u.username, # Or link to Patient/Doctor profile name
                "phone": "N/A" 
            }
        })
    
    return jsonify(user_list), 200

from flask_bcrypt import check_password_hash

@app.route('/api/auth/login', methods=['POST'])
def login():
    data = request.json
    email = data.get('email')
    password = data.get('password')

    user = User.query.filter_by(email=email).first()

    # Verify user exists and password is correct
    if user and check_password_hash(user.password_hash, password):
        # Important: Identity MUST be a string
        access_token = create_access_token(
            identity=str(user.user_id), 
            additional_claims={"role": user.role}
        )
        
        return jsonify({
            "access_token": access_token,
            "role": user.role,
            "entity_id": user.user_id, # Or link to specific profile ID
            "user_info": {"full_name": user.username, "email": user.email}
        }), 200

    return jsonify({"error": "Invalid credentials"}), 401

@app.route('/api/appointments', methods=['GET'])
@jwt_required()
def get_appointments():
    current_user_id = get_jwt_identity()
    claims = get_jwt()
    role = claims.get("role")

    # Dynamic Filtering based on Role
    query = Appointment.query
    if role == 'patient':
        patient = Patient.query.filter_by(user_id=current_user_id).first()
        query = query.filter_by(patient_id=patient.patient_id)
    elif role == 'doctor':
        doctor = Doctor.query.filter_by(user_id=current_user_id).first()
        query = query.filter_by(doctor_id=doctor.doctor_id)
    
    appointments = query.all()
    
    result = []
    for a in appointments:
        pat = Patient.query.get(a.patient_id)
        doc = Doctor.query.get(a.doctor_id)
        result.append({
            "appointment_id": a.appointment_id,
            "patient_id": a.patient_id,
            "patient_name": pat.full_name if pat else "Unknown",
            "doctor_id": a.doctor_id,
            "doctor_name": doc.full_name if doc else "Unknown",
            "doctor_specialization": doc.specialization if doc else "Unknown",
            "appointment_date": str(a.appointment_date),
            "appointment_time": a.appointment_time.strftime('%H:%M') if a.appointment_time else "",
            "status": a.status,
            "notes": a.notes
        })
    
    return jsonify(result), 200


@app.route('/api/appointments/book', methods=['POST'])
@jwt_required()
def book_appointment():
    current_user_id = get_jwt_identity()
    user = User.query.get(int(current_user_id))
    
    data = request.json
    doctor_id = data.get('doctor_id')
    appointment_date = data.get('date')
    appointment_time = data.get('time')
    reason = data.get('reason', '')

    # --- UPDATED VALIDATION BLOCK ---
    if user.role == 'patient':
        # If a patient is logged in, automatically look up their patient profile
        patient = Patient.query.filter_by(user_id=user.user_id).first()
        if not patient:
            return jsonify({"error": "Patient profile not found."}), 404
        patient_id = patient.patient_id
    else:
        # If an Admin/Doctor is logged in, look for a patient_id passed in the request body
        # Default to Patient ID 1 if they are just testing around in the modal
        patient_id = data.get('patient_id', 1) 
    # --------------------------------

    try:
        new_appt = Appointment(
            patient_id=patient_id,
            doctor_id=doctor_id,
            appointment_date=appointment_date,
            appointment_time=appointment_time,
            status="Scheduled",
            notes=reason
        )
        db.session.add(new_appt)
        db.session.commit()
        return jsonify({"message": "Appointment successfully created!"}), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({"error": f"Database booking error: {str(e)}"}), 500

@app.route('/api/appointments/<int:id>/status', methods=['PATCH'])
@jwt_required()
def update_appointment_status(id):
    data = request.json
    new_status = data.get('status')
    
    if new_status not in ['Completed', 'Cancelled']:
        return jsonify({"error": "Invalid status"}), 400

    appt = Appointment.query.get(id)
    if not appt:
        return jsonify({"error": "Appointment not found"}), 404

    appt.status = new_status
    db.session.commit()
    return jsonify({"message": f"Appointment marked as {new_status}"}), 200

@app.route('/api/medications', methods=['GET', 'POST'])
@jwt_required()
def handle_medications():
    current_user_id = get_jwt_identity()
    patient = Patient.query.filter_by(user_id=current_user_id).first()
    
    if not patient:
        return jsonify({"error": "No patient profile found"}), 404

    if request.method == 'POST':
        data = request.json
        try:
            new_med = Medication(
                patient_id=patient.patient_id,
                medicine_name=data['medicine_name'],
                dosage=data.get('dosage'),
                frequency=data.get('frequency'),
                start_date=datetime.strptime(data['start_date'], '%Y-%m-%d').date() if data.get('start_date') else None,
                end_date=datetime.strptime(data['end_date'], '%Y-%m-%d').date() if data.get('end_date') else None,
                reminder_time=datetime.strptime(data['reminder_time'], '%H:%M').time() if data.get('reminder_time') else None
            )
            db.session.add(new_med)
            db.session.commit()
            return jsonify({"message": "Medication added", "medication_id": new_med.medication_id}), 201
        except Exception as e:
            db.session.rollback()
            return jsonify({"error": str(e)}), 400

    meds = Medication.query.filter_by(patient_id=patient.patient_id).all()
    return jsonify([{
        "medication_id": m.medication_id,
        "medicine_name": m.medicine_name,
        "dosage": m.dosage,
        "frequency": m.frequency,
        "start_date": str(m.start_date) if m.start_date else None,
        "end_date": str(m.end_date) if m.end_date else None,
        "reminder_time": m.reminder_time.strftime('%H:%M') if m.reminder_time else None
    } for m in meds]), 200

@app.route('/api/admin/stats', methods=['GET'])
@jwt_required()
def get_admin_stats():
    claims = get_jwt()
    if claims.get("role") != 'admin':
        return jsonify({"error": "Unauthorized"}), 403

    # Query the database for live counts
    stats = {
        "users": User.query.count(),
        "patients": Patient.query.count(),
        "doctors": Doctor.query.count(),
        "appointments": Appointment.query.count()
    }
    
    return jsonify(stats), 200

@app.route('/api/doctors', methods=['GET'])
def get_doctors():
    doctors = Doctor.query.all()
    return jsonify([{
        "doctor_id": d.doctor_id,
        "full_name": d.full_name,
        "specialization": d.specialization,
        "consultation_fee": d.consultation_fee
    } for d in doctors]), 200

@app.route('/api/patients', methods=['GET'])
@jwt_required()
def get_patients():
    claims = get_jwt()
    if claims.get("role") not in ['admin', 'doctor']:
        return jsonify({"error": "Unauthorized"}), 403
    patients = Patient.query.all()
    return jsonify([{
        "patient_id": p.patient_id,
        "full_name": p.full_name,
        "date_of_birth": str(p.date_of_birth),
        "blood_group": p.blood_group,
        "gender": "Unknown",
        "phone": p.phone
    } for p in patients]), 200

@app.route('/api/users', methods=['GET'])
@jwt_required()
def get_users():
    claims = get_jwt()
    if claims.get("role") != 'admin':
        return jsonify({"error": "Unauthorized"}), 403
    users = User.query.all()
    return jsonify([{
        "user_id": u.user_id,
        "username": u.username,
        "email": u.email,
        "role": u.role,
        "is_active": u.is_active
    } for u in users]), 200

@app.route('/api/auth/register', methods=['POST'])
def register():
    data = request.json
    email = data.get('email')
    password = data.get('password')
    full_name = data.get('full_name')
    
    # 1. SECURITY LOCK: Force all public signups to be patients.
    role = 'patient' 

    # 2. Check if email already exists
    if User.query.filter_by(email=email).first():
        return jsonify({"error": "An account with this email already exists"}), 400

    try:
        # 3. Create the core User account
        new_user = User(
            username=email.split('@')[0] + str(int(datetime.now().timestamp())),
            email=email,
            password_hash=hash_password(password),
            role=role
        )
        db.session.add(new_user)
        db.session.commit() # Commit so we get the user_id

        # 4. Create the Patient Profile with ALL required MySQL fields filled with defaults!
        profile = Patient(
            user_id=new_user.user_id, 
            full_name=full_name, 
            date_of_birth=date(2000, 1, 1), # Default DOB
            gender="Other",                 # Default Gender
            phone="0000000000",             # Default Phone
            blood_group="N/A",
            address="Not provided",
            emergency_contact="Not provided"
        )
        db.session.add(profile)
        db.session.commit()

        # 5. Generate secure token
        access_token = create_access_token(identity=str(new_user.user_id))
        
        return jsonify({
            "message": "Account created successfully",
            "access_token": access_token,
            "role": role,
            "entity_id": profile.patient_id,
            "user_info": {"full_name": full_name, "email": email}
        }), 201

    except Exception as e:
        db.session.rollback() # If MySQL crashes, undo the save
        print("SQL ERROR:", str(e)) # Print the exact error to your terminal!
        return jsonify({"error": "Database error: " + str(e)}), 500
    


@app.route('/api/admin/create-staff', methods=['POST'])
@jwt_required() # SECURITY: Must be logged in!
def create_staff():
    # 1. Verify the person making the request is an Admin
    current_user_id = get_jwt_identity()
    admin_user = User.query.get(current_user_id)
    
    if not admin_user or admin_user.role != 'admin':
        return jsonify({"error": "Unauthorized. Only Admins can provision staff."}), 403

    data = request.json
    email = data.get('email')
    full_name = data.get('full_name')
    role = data.get('role')
    default_pw = "MediVault@123"
    hashed_pw = generate_password_hash(default_pw).decode('utf-8')
    
    if not email or not full_name or not role:
        return jsonify({"error": "Email, Name, and Role are required."}), 400
        
    if User.query.filter_by(email=email).first():
        return jsonify({"error": "An account with this email already exists."}), 400
        
    try:
        # 2. Create the core User account (Bypass password hash for OTP)
        new_user = User(
            username=email.split('@')[0] + str(int(datetime.now().timestamp())),
            email=email,
            password_hash=hashed_pw, 
            role=data.get('role')
        )
        db.session.add(new_user)
        db.session.flush() # Flushes to database to grab the new user_id safely
        
        # 3. If they are a doctor, create their specialized profile
        if role == 'doctor':
            new_doctor = Doctor(
                user_id=new_user.user_id,
                full_name=full_name,
                specialization=data.get('specialization', 'General Practice'),
                qualification=data.get('qualification', 'MD'),
                registration_no=f"MED-{random.randint(10000, 99999)}" # Auto-generate a license number
            )
            db.session.add(new_doctor)
            
        db.session.commit()
        return jsonify({"message": f"Account created! Default password: {default_pw}"}), 201
        
    except Exception as e:
        db.session.rollback()
        print("SQL ERROR:", str(e))
        return jsonify({"error": "Database error during provisioning."}), 500

# ─── Initialization & Seeding ────────────────────────────────────────────────

def seed_database():
    """Seeds the database with dynamic test data if empty."""
    if User.query.count() > 0:
        return # DB already seeded

    print("Seeding database with initial data...")
    
    # 1. Create Users
    admin = User(username="admin", email="admin@hospital.com", password_hash=hash_password("Admin@123"), role="admin")
    doc = User(username="dr.mehta", email="dr.mehta@hospital.com", password_hash=hash_password("Doctor@123"), role="doctor")
    pat = User(username="patient1", email="arjun.sharma@email.com", password_hash=hash_password("Patient@123"), role="patient")
    
    db.session.add_all([admin, doc, pat])
    db.session.commit()

    # 2. Create Profiles
    doctor_profile = Doctor(user_id=doc.user_id, full_name="Dr. Rakesh Mehta", specialization="Cardiology", registration_no="RJ-MED-2048")
    patient_profile = Patient(user_id=pat.user_id, full_name="Arjun Sharma", date_of_birth=date(1990, 4, 15), blood_group="B+")
    
    db.session.add_all([doctor_profile, patient_profile])
    db.session.commit()

    # 3. Create Interactions
    appt = Appointment(patient_id=patient_profile.patient_id, doctor_id=doctor_profile.doctor_id, appointment_date=date(2026, 5, 12), appointment_time=dtime(10, 0), notes="Chest pain follow-up")
    med = Medication(patient_id=patient_profile.patient_id, medicine_name="Amlodipine", dosage="5mg", frequency="Daily", reminder_time=dtime(8, 0))
    
    db.session.add_all([appt, med])
    db.session.commit()
    print("Database seeded successfully!")

# ─── ENTRY POINT ─────────────────────────────────────────────────────────────

if __name__ == "__main__":
    with app.app_context():
        db.create_all()  # Dynamically creates missing tables
        seed_database()  # Injects mock users so you can log in immediately
    
    # Run the server
    app.run(debug=True, port=5001)