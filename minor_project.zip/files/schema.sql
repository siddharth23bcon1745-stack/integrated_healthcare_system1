-- ============================================================
--  Integrated Healthcare Management System — MySQL Schema
--  Source: Chapter 3 (Database Design), Minor Project Report
--  JECRC University, Jaipur — Session 2025-26
--  Standard: Third Normal Form (3NF)
-- ============================================================

CREATE DATABASE IF NOT EXISTS healthcare_db
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE healthcare_db;

-- ─── Table 3.1 · Users ──────────────────────────────────────────────────────
CREATE TABLE users (
    user_id        INT           PRIMARY KEY AUTO_INCREMENT,
    username       VARCHAR(50)   NOT NULL UNIQUE,
    password_hash  VARCHAR(255)  NOT NULL,          -- bcrypt, cost factor 12
    email          VARCHAR(100)  NOT NULL UNIQUE,
    role           ENUM('patient','doctor','admin') NOT NULL,
    created_at     TIMESTAMP     DEFAULT CURRENT_TIMESTAMP,
    is_active      BOOLEAN       DEFAULT TRUE
);

-- ─── Table 3.2 · Patients ───────────────────────────────────────────────────
CREATE TABLE patients (
    patient_id         INT          PRIMARY KEY AUTO_INCREMENT,
    user_id            INT          NOT NULL,
    full_name          VARCHAR(100) NOT NULL,
    date_of_birth      DATE         NOT NULL,
    gender             ENUM('Male','Female','Other') NOT NULL,
    blood_group        VARCHAR(5),                  -- ABO system
    phone              VARCHAR(15)  NOT NULL,
    address            TEXT,
    emergency_contact  VARCHAR(100),
    FOREIGN KEY (user_id)
        REFERENCES users(user_id)
        ON DELETE CASCADE
        ON UPDATE CASCADE
);

-- ─── Table 3.3 · Doctors ────────────────────────────────────────────────────
CREATE TABLE doctors (
    doctor_id         INT           PRIMARY KEY AUTO_INCREMENT,
    user_id           INT           NOT NULL,
    full_name         VARCHAR(100)  NOT NULL,
    specialization    VARCHAR(100)  NOT NULL,
    qualification     VARCHAR(200)  NOT NULL,
    registration_no   VARCHAR(50)   UNIQUE,         -- Medical Council reg. no.
    consultation_fee  DECIMAL(10,2),
    FOREIGN KEY (user_id)
        REFERENCES users(user_id)
        ON DELETE CASCADE
        ON UPDATE CASCADE
);

-- ─── Table 3.4 · Appointments ───────────────────────────────────────────────
CREATE TABLE appointments (
    appointment_id    INT       PRIMARY KEY AUTO_INCREMENT,
    patient_id        INT       NOT NULL,
    doctor_id         INT       NOT NULL,
    appointment_date  DATE      NOT NULL,
    appointment_time  TIME      NOT NULL,
    status            ENUM('Scheduled','Completed','Cancelled') NOT NULL,
    notes             TEXT,
    created_at        TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (patient_id)
        REFERENCES patients(patient_id)
        ON DELETE CASCADE
        ON UPDATE CASCADE,
    FOREIGN KEY (doctor_id)
        REFERENCES doctors(doctor_id)
        ON DELETE CASCADE
        ON UPDATE CASCADE,
    -- Prevent double-booking: one active appointment per doctor per slot
    UNIQUE KEY uq_doctor_slot (doctor_id, appointment_date, appointment_time, status)
);

-- ─── Table 3.5 · Health Records (EHR) ───────────────────────────────────────
CREATE TABLE health_records (
    record_id       INT          PRIMARY KEY AUTO_INCREMENT,
    patient_id      INT          NOT NULL,
    doctor_id       INT          NOT NULL,
    visit_date      DATE         NOT NULL,
    diagnosis       TEXT,
    prescription    TEXT,
    lab_reports     VARCHAR(500),                   -- comma-separated file paths
    follow_up_date  DATE,
    FOREIGN KEY (patient_id)
        REFERENCES patients(patient_id)
        ON DELETE CASCADE
        ON UPDATE CASCADE,
    FOREIGN KEY (doctor_id)
        REFERENCES doctors(doctor_id)
        ON DELETE SET NULL
        ON UPDATE CASCADE
);

-- ─── Table 3.6 · Medications ────────────────────────────────────────────────
CREATE TABLE medications (
    medication_id  INT          PRIMARY KEY AUTO_INCREMENT,
    patient_id     INT          NOT NULL,
    medicine_name  VARCHAR(100) NOT NULL,
    dosage         VARCHAR(50)  NOT NULL,
    frequency      VARCHAR(50)  NOT NULL,           -- e.g. Daily, Twice Daily
    start_date     DATE         NOT NULL,
    end_date       DATE,
    reminder_time  TIME,                            -- alert time for notification
    FOREIGN KEY (patient_id)
        REFERENCES patients(patient_id)
        ON DELETE CASCADE
        ON UPDATE CASCADE
);

-- ─── Indexes for fast retrieval ──────────────────────────────────────────────
CREATE INDEX idx_appointments_patient   ON appointments  (patient_id);
CREATE INDEX idx_appointments_doctor    ON appointments  (doctor_id);
CREATE INDEX idx_appointments_date      ON appointments  (appointment_date);
CREATE INDEX idx_health_records_patient ON health_records(patient_id);
CREATE INDEX idx_medications_patient    ON medications   (patient_id);

-- ─── Seed data (demo) ────────────────────────────────────────────────────────
-- Passwords are bcrypt hashes of 'Patient@123', 'Doctor@123', 'Admin@123'
INSERT INTO users (username, password_hash, email, role) VALUES
('arjun.sharma',  '$2b$12$exampleHashPatient1', 'arjun.sharma@email.com',    'patient'),
('dr.mehta',      '$2b$12$exampleHashDoctor1',  'dr.mehta@hospital.com',     'doctor'),
('admin',         '$2b$12$exampleHashAdmin1',   'admin@healthcare.com',      'admin'),
('meera.patel',   '$2b$12$exampleHashPatient2', 'meera.patel@email.com',     'patient'),
('dr.agarwal',    '$2b$12$exampleHashDoctor2',  'dr.agarwal@hospital.com',   'doctor');

INSERT INTO patients (user_id, full_name, date_of_birth, gender, blood_group, phone, address, emergency_contact) VALUES
(1, 'Arjun Sharma',  '1990-04-15', 'Male',   'B+', '9876543210', '12 Tonk Road, Jaipur',   'Priya Sharma – 9876543211'),
(4, 'Meera Patel',   '1985-09-22', 'Female', 'O+', '9812345678', '45 C-Scheme, Jaipur',    'Ravi Patel – 9812345679');

INSERT INTO doctors (user_id, full_name, specialization, qualification, registration_no, consultation_fee) VALUES
(2, 'Dr. Rakesh Mehta',   'Cardiology',       'MBBS, MD (Cardiology)', 'RJ-MED-2048', 800.00),
(5, 'Dr. Sunita Agarwal', 'General Medicine', 'MBBS, MD (Gen. Med)',   'RJ-MED-3192', 500.00);

INSERT INTO appointments (patient_id, doctor_id, appointment_date, appointment_time, status, notes) VALUES
(1, 1, '2026-05-12', '10:00:00', 'Scheduled',  'Follow-up for chest pain'),
(2, 2, '2026-05-10', '14:30:00', 'Completed',  'Routine checkup'),
(1, 2, '2026-04-28', '09:00:00', 'Completed',  'Fever and cold');

INSERT INTO health_records (patient_id, doctor_id, visit_date, diagnosis, prescription, lab_reports, follow_up_date) VALUES
(1, 1, '2026-04-28', 'Viral Fever, Common Cold',
 'Paracetamol 500mg – 3x daily; Cetirizine 10mg – 1x at night',
 'uploads/cbc_arjun.pdf,uploads/thyroid_arjun.pdf', '2026-05-12'),
(1, 2, '2026-03-10', 'Hypertension – Stage 1',
 'Amlodipine 5mg – 1x daily; Low-sodium diet advised',
 'uploads/lipid_arjun.pdf,uploads/ecg_arjun.pdf',   '2026-04-10');

INSERT INTO medications (patient_id, medicine_name, dosage, frequency, start_date, end_date, reminder_time) VALUES
(1, 'Amlodipine',  '5mg',   'Daily',     '2026-03-10', '2026-06-10', '08:00:00'),
(1, 'Paracetamol', '500mg', '3x Daily',  '2026-04-28', '2026-05-05', '07:00:00'),
(2, 'Metformin',   '500mg', 'Twice Daily','2026-05-10', '2026-11-10','07:30:00');
