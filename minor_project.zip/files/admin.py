from app import app, db, User
from flask_bcrypt import generate_password_hash # Use the same one as your app.py

def create_master_admin():
    with app.app_context():
        # 1. Clear old broken admin if it exists
        User.query.filter_by(email="admin@healthcare.com").delete()
        
        # 2. Generate a VALID salt/hash
        hashed_pw = generate_password_hash("admin123").decode('utf-8')
        
        admin = User(
            username="master_admin",
            email="admin@Medivault.com",
            password_hash=hashed_pw, # Now a valid bcrypt string
            role="admin",
            is_active=True
        )
        
        try:
            db.session.add(admin)
            db.session.commit()
            print("✅ Admin account 'admin@healthcare.com' recreated with valid salt!")
        except Exception as e:
            db.session.rollback()
            print(f"❌ Error: {e}")

if __name__ == "__main__":
    create_master_admin()