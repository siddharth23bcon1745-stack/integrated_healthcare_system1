import React, { useState, useEffect } from "react";
import { 
  Activity, Calendar, FileText, Bell, MessageSquare, Users, 
  LogOut, ChevronRight, Clock, Heart, Pill, AlertTriangle, 
  User, Stethoscope, Shield, Plus, Search, X, Check, 
  TrendingUp, Database, Settings, Home, Eye, Edit, ChevronLeft,
  Phone, Mail, MapPin, Droplet, ChevronDown, CheckCircle, Download, 
  XCircle, BarChart2, ClipboardList, UserCheck, Zap, Send, Upload, Lock,Trash2 
} from "lucide-react";

// ─── Palette & Theme ────────────────────────────────────────────────────────
const API_URL = "http://127.0.0.1:5001/api";
const C = {
  navy: "#0A2342",
  navyMid: "#123264",
  navyLight: "#1E4080",
  accent: "#2E86AB",
  accentLight: "#4EA8C9",
  gold: "#D4A843",
  white: "#F8FAFC",
  gray50: "#F1F5F9",
  gray100: "#E2E8F0",
  gray400: "#94A3B8",
  gray600: "#475569",
  gray800: "#1E293B",
  green: "#10B981",
  red: "#EF4444",
  amber: "#F59E0B",
};

// ─── Seed Data (mirrors DB schema from report) ───────────────────────────────
const USERS = [
  { user_id: 1, username: "patient1", email: "arjun.sharma@email.com", role: "patient", is_active: true },
  { user_id: 2, username: "dr.mehta", email: "dr.mehta@hospital.com", role: "doctor", is_active: true },
  { user_id: 3, username: "admin", email: "admin@hospital.com", role: "admin", is_active: true },
];

const PATIENTS = [
  { patient_id: 1, user_id: 1, full_name: "Arjun Sharma", date_of_birth: "1990-04-15", gender: "Male", blood_group: "B+", phone: "9876543210", address: "12 Tonk Road, Jaipur", emergency_contact: "Priya Sharma – 9876543211" },
  { patient_id: 2, user_id: 4, full_name: "Meera Patel", date_of_birth: "1985-09-22", gender: "Female", blood_group: "O+", phone: "9812345678", address: "45 C-Scheme, Jaipur", emergency_contact: "Ravi Patel – 9812345679" },
  { patient_id: 3, user_id: 5, full_name: "Rahul Gupta", date_of_birth: "2000-01-10", gender: "Male", blood_group: "A-", phone: "9923456789", address: "7 Vaishali Nagar, Jaipur", emergency_contact: "Suman Gupta – 9923456780" },
];

const DOCTORS = [
  { doctor_id: 1, user_id: 2, full_name: "Dr. Rakesh Mehta", specialization: "Cardiology", qualification: "MBBS, MD (Cardiology)", registration_no: "RJ-MED-2048", consultation_fee: 800 },
  { doctor_id: 2, user_id: 6, full_name: "Dr. Sunita Agarwal", specialization: "General Medicine", qualification: "MBBS, MD (Gen. Med)", registration_no: "RJ-MED-3192", consultation_fee: 500 },
  { doctor_id: 3, user_id: 7, full_name: "Dr. Vikram Joshi", specialization: "Orthopedics", qualification: "MBBS, MS (Ortho)", registration_no: "RJ-MED-4201", consultation_fee: 700 },
];

const APPOINTMENTS_INIT = [
  { appointment_id: 1, patient_id: 1, doctor_id: 1, appointment_date: "2026-05-12", appointment_time: "10:00", status: "Scheduled", notes: "Follow-up for chest pain" },
  { appointment_id: 2, patient_id: 2, doctor_id: 2, appointment_date: "2026-05-10", appointment_time: "14:30", status: "Completed", notes: "Routine checkup" },
  { appointment_id: 3, patient_id: 3, doctor_id: 3, appointment_date: "2026-05-14", appointment_time: "11:00", status: "Scheduled", notes: "Knee pain assessment" },
  { appointment_id: 4, patient_id: 1, doctor_id: 2, appointment_date: "2026-04-28", appointment_time: "09:00", status: "Completed", notes: "Fever and cold" },
];

const HEALTH_RECORDS = [
  { record_id: 1, patient_id: 1, doctor_id: 1, visit_date: "2026-04-28", diagnosis: "Viral Fever, Common Cold", prescription: "Paracetamol 500mg – 3x daily; Cetirizine 10mg – 1x at night", lab_reports: "CBC, Thyroid Panel", follow_up_date: "2026-05-12" },
  { record_id: 2, patient_id: 1, doctor_id: 2, visit_date: "2026-03-10", diagnosis: "Hypertension – Stage 1", prescription: "Amlodipine 5mg – 1x daily; Low-sodium diet advised", lab_reports: "Lipid Profile, ECG", follow_up_date: "2026-04-10" },
  { record_id: 3, patient_id: 2, doctor_id: 2, visit_date: "2026-05-10", diagnosis: "Type 2 Diabetes (controlled)", prescription: "Metformin 500mg – 2x daily; Monitor fasting glucose weekly", lab_reports: "HbA1c, FBS", follow_up_date: "2026-07-10" },
];

const MEDICATIONS_INIT = [
  { medication_id: 1, patient_id: 1, medicine_name: "Amlodipine", dosage: "5mg", frequency: "Daily", start_date: "2026-03-10", end_date: "2026-06-10", reminder_time: "08:00" },
  { medication_id: 2, patient_id: 1, medicine_name: "Paracetamol", dosage: "500mg", frequency: "3x Daily", start_date: "2026-04-28", end_date: "2026-05-05", reminder_time: "07:00" },
  { medication_id: 3, patient_id: 2, medicine_name: "Metformin", dosage: "500mg", frequency: "Twice Daily", start_date: "2026-05-10", end_date: "2026-11-10", reminder_time: "07:30" },
];

// Time slots pool for scheduling
const TIME_SLOTS = ["09:00","09:30","10:00","10:30","11:00","11:30","14:00","14:30","15:00","15:30","16:00","16:30"];

// ─── Tiny UI Atoms ────────────────────────────────────────────────────────────
const Badge = ({ label, color }) => {
  const map = { Scheduled: [C.accent, "#EFF8FF"], Completed: [C.green, "#ECFDF5"], Cancelled: [C.red, "#FEF2F2"], Active: [C.green, "#ECFDF5"], Inactive: [C.gray400, C.gray50] };
  const [fg, bg] = map[color] || map[label] || [C.gray600, C.gray100];
  return <span style={{ background: bg, color: fg, border: `1px solid ${fg}33`, borderRadius: 20, padding: "2px 10px", fontSize: 12, fontWeight: 600, letterSpacing: 0.3 }}>{label}</span>;
};

const Card = ({ children, style = {}, onClick, onMouseEnter, onMouseLeave }) => (
  <div 
    onClick={onClick}
    onMouseEnter={onMouseEnter}
    onMouseLeave={onMouseLeave}
    style={{ background: "#fff", borderRadius: 12, boxShadow: "0 2px 12px rgba(10,35,66,0.08)", border: `1px solid ${C.gray100}`, ...style }}
  >
    {children}
  </div>
);

const Stat = ({ icon: Icon, label, value, sub, accent, onClick }) => (
  <Card 
    onClick={onClick}
    onMouseEnter={(e) => onClick && (e.currentTarget.style.transform = 'translateY(-2px)')}
    onMouseLeave={(e) => onClick && (e.currentTarget.style.transform = 'translateY(0)')}
    style={{ 
      padding: "20px 24px", 
      display: "flex", 
      alignItems: "center", 
      gap: 16,
      cursor: onClick ? 'pointer' : 'default',
      transition: 'all 0.2s ease',
    }}
  >
    <div style={{ background: accent || C.navy, borderRadius: 10, padding: 12, flexShrink: 0 }}>
      <Icon size={22} color="#fff" />
    </div>
    <div>
      <div style={{ fontSize: 26, fontWeight: 700, color: C.navy, lineHeight: 1 }}>{value}</div>
      <div style={{ fontSize: 13, color: C.gray600, marginTop: 3 }}>{label}</div>
      {sub && <div style={{ fontSize: 11, color: C.accent, marginTop: 2 }}>{sub}</div>}
    </div>
  </Card>
);

const Btn = ({ children, onClick, variant = "primary", style = {}, disabled }) => {
  const styles = {
    primary: { background: C.navy, color: "#fff", border: "none" },
    outline: { background: "transparent", color: C.navy, border: `1.5px solid ${C.navy}` },
    accent: { background: C.accent, color: "#fff", border: "none" },
    danger: { background: C.red, color: "#fff", border: "none" },
    ghost: { background: "transparent", color: C.gray600, border: `1px solid ${C.gray100}` },
  };
  return (
    <button onClick={onClick} disabled={disabled}
      style={{ ...styles[variant], borderRadius: 8, padding: "8px 18px", fontSize: 13, fontWeight: 600, cursor: disabled ? "not-allowed" : "pointer", opacity: disabled ? 0.5 : 1, display: "flex", alignItems: "center", gap: 6, transition: "opacity 0.15s", ...style }}>
      {children}
    </button>
  );
};

const Input = ({ label, value, onChange, type = "text", options, style = {} }) => (
  <div style={{ display: "flex", flexDirection: "column", gap: 4, ...style }}>
    {label && <label style={{ fontSize: 12, fontWeight: 600, color: C.gray600, letterSpacing: 0.4 }}>{label.toUpperCase()}</label>}
    {options ? (
      <select value={value} onChange={e => onChange(e.target.value)}
        style={{ border: `1.5px solid ${C.gray100}`, borderRadius: 8, padding: "8px 12px", fontSize: 13, color: C.navy, outline: "none", background: "#fff" }}>
        {options.map(o => <option key={o.value || o} value={o.value || o}>{o.label || o}</option>)}
      </select>
    ) : (
      <input type={type} value={value} onChange={e => onChange(e.target.value)}
        style={{ border: `1.5px solid ${C.gray100}`, borderRadius: 8, padding: "8px 12px", fontSize: 13, color: C.navy, outline: "none" }} />
    )}
  </div>
);

const Modal = ({ title, onClose, children }) => (
  <div style={{ position: "fixed", inset: 0, background: "rgba(10,35,66,0.55)", zIndex: 1000, display: "flex", alignItems: "center", justifyContent: "center", padding: 16 }}>
    <Card style={{ width: "100%", maxWidth: 520, padding: 28, position: "relative", maxHeight: "90vh", overflowY: "auto" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
        <h3 style={{ margin: 0, color: C.navy, fontSize: 18, fontWeight: 700 }}>{title}</h3>
        <button onClick={onClose} style={{ background: "none", border: "none", cursor: "pointer", color: C.gray400 }}><X size={20} /></button>
      </div>
      {children}
    </Card>
  </div>
);

// ─── AUTHENTICATION SCREEN (PRODUCTION MODE) ─────────────────────────────────
const AuthScreen = ({ onLogin }) => {
  const [isLoginView, setIsLoginView] = useState(true);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  // Login States
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  // Register States
  const [regName, setRegName] = useState("");
  const [regEmail, setRegEmail] = useState("");
  const [regPassword, setRegPassword] = useState("");
  const [regRole, setRegRole] = useState("patient");

const handleLogin = async () => {
  if (!email || !password) {
    setError("Please enter both email and password.");
    return;
  }
  
  setLoading(true); setError("");

  try {
    const response = await fetch(`${API_URL}/auth/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password }) // Sending both credentials
    });

    const data = await response.json();

    if (response.ok) {
      onLogin(data); // This saves the session and token
    } else {
      setError(data.error || "Invalid email or password.");
    }
  } catch (err) {
    setError("Server connection failed.");
  } finally {
    setLoading(false);
  }
};

const handleRegister = async () => {
    if (!regName || !regEmail || !regPassword) {
      setError("Please fill in all fields.");
      return;
    }

    setLoading(true); setError("");

    try {
      const response = await fetch(`${API_URL}/auth/register`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          email: regEmail,
          password: regPassword,
          full_name: regName,
          role: "patient" // SECURITY LOCK: Force all public signups to be patients!
        })
      });

      const data = await response.json();

      if (response.ok) {
        onLogin(data); 
      } else {
        setError(data.error || "Registration failed.");
      }
    } catch (err) {
      setError("Server connection failed.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ minHeight: "100vh", background: `linear-gradient(135deg, ${C.navy} 0%, ${C.navyLight} 60%, ${C.accent} 100%)`, display: "flex", alignItems: "center", justifyContent: "center", padding: 16 }}>
      <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 24, width: "100%", maxWidth: 420 }}>
        
        <div style={{ textAlign: "center" }}>
          <div style={{ background: "rgba(255,255,255,0.12)", borderRadius: 20, padding: "16px 20px", display: "inline-flex", alignItems: "center", gap: 12, marginBottom: 12 }}>
            <Activity size={32} color={C.gold} />
            <div style={{ textAlign: "left" }}>
              <div style={{ color: "#fff", fontWeight: 800, fontSize: 18, letterSpacing: 0.5 }}>Medi Vault HMS</div>
              <div style={{ color: "rgba(255,255,255,0.6)", fontSize: 11, letterSpacing: 1 }}>SECURE ACCESS</div>
            </div>
          </div>
        </div>

        <Card style={{ width: "100%", padding: 32 }}>
          <div style={{ display: "flex", gap: 16, marginBottom: 24, borderBottom: `2px solid ${C.gray50}` }}>
            <button onClick={() => { setIsLoginView(true); setError(""); }} style={{ flex: 1, paddingBottom: 12, background: "none", border: "none", borderBottom: isLoginView ? `2px solid ${C.navy}` : "2px solid transparent", color: isLoginView ? C.navy : C.gray400, fontWeight: 700, fontSize: 15, cursor: "pointer", marginBottom: -2 }}>Sign In</button>
            <button onClick={() => { setIsLoginView(false); setError(""); }} style={{ flex: 1, paddingBottom: 12, background: "none", border: "none", borderBottom: !isLoginView ? `2px solid ${C.navy}` : "2px solid transparent", color: !isLoginView ? C.navy : C.gray400, fontWeight: 700, fontSize: 15, cursor: "pointer", marginBottom: -2 }}>Register</button>
          </div>

          {error && <div style={{ color: C.red, fontSize: 13, background: "#FEF2F2", padding: "10px 14px", borderRadius: 8, marginBottom: 16, border: `1px solid ${C.red}` }}>{error}</div>}

          {isLoginView ? (
            <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
              <Input label="Email Address" value={email} onChange={setEmail} type="email" />
              <Input label="Password" value={password} onChange={setPassword} type="password" />
              <Btn onClick={handleLogin} disabled={loading} style={{ width: "100%", justifyContent: "center", padding: "11px 18px", fontSize: 14, marginTop: 8 }}>
                {loading ? "Authenticating..." : <>Sign In <ChevronRight size={16} /></>}
              </Btn>
            </div>
          ) : (
            <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
              {/* DROPDOWN REMOVED: No more choosing to be a doctor! */}
              <Input label="Full Name" value={regName} onChange={setRegName} />
              <Input label="Email Address" value={regEmail} onChange={setRegEmail} type="email" />
              <Input label="Create Password" value={regPassword} onChange={setRegPassword} type="password" />
              
              <Btn onClick={handleRegister} disabled={loading} style={{ width: "100%", justifyContent: "center", padding: "11px 18px", fontSize: 14, marginTop: 8 }}>
                {loading ? "Creating Account..." : <>Create Account <ChevronRight size={16} /></>}
              </Btn>
            </div>
          
          )}
        </Card>
      </div>
    </div>
  );
};

// ─── SIDEBAR ──────────────────────────────────────────────────────────────────
const Sidebar = ({ role, active, setActive, onLogout }) => {
  const menus = {
    patient: [
      { id: "dashboard", icon: Home, label: "Dashboard" },
      { id: "appointments", icon: Calendar, label: "Appointments" },
      { id: "records", icon: FileText, label: "Health Records" },
      { id: "medications", icon: Pill, label: "Medications" },
      { id: "messages", icon: MessageSquare, label: "Messages" },
    ],
    doctor: [
      { id: "dashboard", icon: Home, label: "Dashboard" },
      { id: "patients", icon: Users, label: "My Patients" },
      { id: "appointments", icon: Calendar, label: "Appointments" },
      { id: "records", icon: FileText, label: "Health Records" },
    ],
    admin: [
      { id: "dashboard", icon: Home, label: "Dashboard" },
      { id: "users", icon: Users, label: "User Management" },
      { id: "appointments", icon: Calendar, label: "All Appointments" },
      { id: "analytics", icon: BarChart2, label: "Analytics" },
      { id: "settings", icon: Settings, label: "System Config" },
    ],
  };

  const roleLabels = { patient: "Patient Portal", doctor: "Doctor Portal", admin: "Admin Panel" };
  const roleIcons = { patient: User, doctor: Stethoscope, admin: Shield };
  const RoleIcon = roleIcons[role];

  return (
    <div style={{ width: 230, minHeight: "100vh", background: C.navy, display: "flex", flexDirection: "column", flexShrink: 0 }}>
      {/* Header */}
      <div style={{ padding: "24px 20px 20px", borderBottom: "1px solid rgba(255,255,255,0.08)" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 4 }}>
          <Activity size={22} color={C.gold} />
          <span style={{ color: "#fff", fontWeight: 800, fontSize: 16, letterSpacing: 0.3 }}>Medi Vault</span>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 8, marginTop: 14 }}>
          <div style={{ background: "rgba(255,255,255,0.12)", borderRadius: 8, padding: 6 }}><RoleIcon size={14} color="rgba(255,255,255,0.8)" /></div>
          <span style={{ color: "rgba(255,255,255,0.6)", fontSize: 11, fontWeight: 600, letterSpacing: 0.5 }}>{roleLabels[role].toUpperCase()}</span>
        </div>
      </div>

      {/* Nav */}
      <nav style={{ flex: 1, padding: "12px 10px" }}>
        {menus[role].map(({ id, icon: Icon, label }) => {
          const isActive = active === id;
          return (
            <button key={id} onClick={() => setActive(id)}
              style={{ width: "100%", display: "flex", alignItems: "center", gap: 11, padding: "10px 12px", borderRadius: 8, border: "none", background: isActive ? "rgba(46,134,171,0.3)" : "transparent", color: isActive ? "#fff" : "rgba(255,255,255,0.55)", fontSize: 13, fontWeight: isActive ? 600 : 400, cursor: "pointer", marginBottom: 2, textAlign: "left", transition: "all 0.15s", borderLeft: isActive ? `3px solid ${C.accentLight}` : "3px solid transparent" }}>
              <Icon size={16} />
              {label}
            </button>
          );
        })}
      </nav>

      {/* Logout */}
      <div style={{ padding: "16px 10px", borderTop: "1px solid rgba(255,255,255,0.08)" }}>
        <button onClick={onLogout}
          style={{ width: "100%", display: "flex", alignItems: "center", gap: 11, padding: "10px 12px", borderRadius: 8, border: "none", background: "transparent", color: "rgba(255,255,255,0.45)", fontSize: 13, cursor: "pointer" }}>
          <LogOut size={16} /> Sign Out
        </button>
      </div>
    </div>
  );
};

// ─── TOPBAR ───────────────────────────────────────────────────────────────────
const TopBar = ({ title, userName, setActive }) => (
  <div style={{ background: "#fff", borderBottom: `1px solid ${C.gray100}`, padding: "0 28px", height: 60, display: "flex", alignItems: "center", justifyContent: "space-between", flexShrink: 0 }}>
    <h1 style={{ margin: 0, fontSize: 18, fontWeight: 700, color: C.navy, textTransform: 'capitalize' }}>{title}</h1>
    <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
      {/* Notification Bell */}
      <button 
        onClick={() => setActive('messages')} 
        style={{ background: 'none', border: 'none', cursor: 'pointer', position: "relative", padding: 4 }}
      >
        <Bell size={18} color={C.gray400} />
        <div style={{ position: "absolute", top: 2, right: 2, width: 8, height: 8, background: C.red, borderRadius: "50%", border: "1.5px solid #fff" }} />
      </button>

      {/* Profile Section */}
      <button 
        onClick={() => setActive('profile')}
        style={{ background: 'none', border: 'none', cursor: 'pointer', display: "flex", alignItems: "center", gap: 8, padding: '4px 8px', borderRadius: 8, transition: 'background 0.2s' }}
        onMouseOver={(e) => e.currentTarget.style.background = C.gray50}
        onMouseOut={(e) => e.currentTarget.style.background = 'none'}
      >
        <div style={{ width: 32, height: 32, borderRadius: "50%", background: `linear-gradient(135deg, ${C.navy}, ${C.accent})`, display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontSize: 13, fontWeight: 700 }}>
          {userName?.charAt(0)?.toUpperCase()}
        </div>
        <span style={{ fontSize: 13, fontWeight: 600, color: C.navy }}>{userName}</span>
      </button>
    </div>
  </div>
);

// ─── PATIENT DASHBOARD ────────────────────────────────────────────────────────
const PatientDashboard = ({ auth, setActive }) => {
  const [stats, setStats] = useState({ upcoming: 0, records: 0, meds: 0 });
  const [recentAppts, setRecentAppts] = useState([]);

  useEffect(() => {
    const myId = auth.entity_id;

    // 1. Get Live Appointment Data
    const appts = JSON.parse(localStorage.getItem("medivault_appointments_db") || "[]");
    const myAppts = appts.filter(a => a.patient_id === myId && a.status === "Scheduled");
    
    // 2. Get Live Records Count
    const records = JSON.parse(localStorage.getItem("medivault_records_db") || "[]");
    const myRecords = records.filter(r => r.patient_id === myId);

    // 3. Get Live Medications Count
    const meds = JSON.parse(localStorage.getItem("medivault_medications_db") || "[]");
    const myMeds = meds.filter(m => m.patient_id === myId);

    setStats({
      upcoming: myAppts.length,
      records: myRecords.length,
      meds: myMeds.length
    });
    setRecentAppts(myAppts.slice(0, 2));
  }, [auth.entity_id]);

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 24 }}>
      <div style={{ background: `linear-gradient(120deg, ${C.navy} 0%, ${C.navyLight} 100%)`, borderRadius: 14, padding: "24px 28px", color: "#fff" }}>
        <div style={{ fontSize: 12, opacity: 0.7, marginBottom: 4 }}>PATIENT PORTAL</div>
        <div style={{ fontSize: 22, fontWeight: 700 }}>{auth.user_info?.full_name}</div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))", gap: 16 }}>
        <Stat icon={Calendar} label="Scheduled" value={stats.upcoming} sub="Next Appt" accent={C.accent} onClick={() => setActive('appointments')} />
        <Stat icon={FileText} label="Health Files" value={stats.records} sub="View Reports" accent={C.navyLight} onClick={() => setActive('records')} />
        <Stat icon={Pill} label="Medications" value={stats.meds} sub="Active Prescriptions" accent={C.green} onClick={() => setActive('medications')} />
        <Stat icon={MessageSquare} label="New Msgs" value="Live" sub="Check Inbox" accent={C.gold} onClick={() => setActive('messages')} />
      </div>

      <Card style={{ padding: 22 }}>
        <h3 style={{ margin: "0 0 16px", color: C.navy, fontSize: 15, fontWeight: 700 }}>Upcoming Schedule</h3>
        {recentAppts.length === 0 ? (
          <div style={{ color: C.gray400, fontSize: 13, textAlign: "center", padding: "20px 0" }}>No upcoming appointments.</div>
        ) : recentAppts.map(a => (
          <div key={a.appointment_id} style={{ padding: "12px", border: `1px solid ${C.gray50}`, borderRadius: 8, marginBottom: 8 }}>
            <div style={{ fontWeight: 600, color: C.navy, fontSize: 14 }}>{a.doctor_name}</div>
            <div style={{ color: C.gray600, fontSize: 12 }}>{a.appointment_date} at {a.appointment_time}</div>
          </div>
        ))}
      </Card>
    </div>
  );
};

// ─── APPOINTMENT SCHEDULING (PERSISTENT) ──────────────────────────────────────
const AppointmentScheduler = ({ role, auth }) => {
  const [appointments, setAppointments] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [form, setForm] = useState({ doctor_id: "1", date: new Date().toISOString().split('T')[0], reason: "" });
  const [success, setSuccess] = useState("");

  const myID = auth.entity_id;
  const myEmail = auth.user_info?.email;

  // 1. Load Appointments from Mock DB
 // 1. Fetch Appointments from Flask
  const loadAppts = async () => {
    try {
      const response = await fetch(`${API_URL}/appointments`, {
        headers: { "Authorization": `Bearer ${auth.access_token}` }
      });
      if (response.ok) {
        const data = await response.json();
        setAppointments(data.reverse()); // Put newest at the top
      }
    } catch (err) {
      console.error("Failed to load appointments:", err);
    }
  };

  useEffect(() => {
    loadAppts();
  }, [role, myID]);

  // 2. Book an Appointment via Flask
  const handleBook = async (time) => {
    try {
      const response = await fetch(`${API_URL}/appointments/book`, {
        method: "POST",
        headers: { 
          "Content-Type": "application/json",
          "Authorization": `Bearer ${auth.access_token}`
        },
        body: JSON.stringify({
          doctor_id: parseInt(form.doctor_id),
          date: form.date,
          time: time,
          reason: form.reason
        })
      });

      if (response.ok) {
        loadAppts(); // Refresh the list from the DB
        setShowModal(false);
        setSuccess(`Success! Appointment booked for ${time}`);
        setTimeout(() => setSuccess(""), 4000);
      } else {
        const errData = await response.json();
        alert(errData.error || "Failed to book appointment.");
      }
    } catch (err) {
      console.error(err);
    }
  };

  // 3. Update Status (Complete / Cancel) via Flask
  const updateStatus = async (id, newStatus) => {
    try {
      const response = await fetch(`${API_URL}/appointments/${id}/status`, {
        method: "PATCH",
        headers: { 
          "Content-Type": "application/json",
          "Authorization": `Bearer ${auth.access_token}`
        },
        body: JSON.stringify({ status: newStatus })
      });

      if (response.ok) {
        loadAppts(); // Refresh the screen
      }
    } catch (err) {
      console.error(err);
    }
  };

  const bookedSlots = appointments
    .filter(a => String(a.doctor_id) === String(form.doctor_id) && a.appointment_date === form.date && a.status === "Scheduled")
    .map(a => a.appointment_time);

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div>
          <h2 style={{ margin: 0, color: C.navy, fontSize: 20, fontWeight: 700 }}>
            {role === "patient" ? "My Appointments" : role === "doctor" ? "Appointment Queue" : "All Appointments"}
          </h2>
          <p style={{ margin: "4px 0 0", color: C.gray600, fontSize: 13 }}>Manage your schedule and consultations</p>
        </div>
        {role === "patient" && <Btn onClick={() => setShowModal(true)} variant="accent"><Plus size={15} /> Book Appointment</Btn>}
      </div>

      {success && (
        <div style={{ background: "#ECFDF5", border: `1px solid ${C.green}`, borderRadius: 8, padding: "12px 16px", color: C.green, fontSize: 13, display: "flex", alignItems: "center", gap: 8 }}>
          <CheckCircle size={16} />{success}
        </div>
      )}

      <Card>
        <div style={{ overflowX: "auto" }}>
          <table style={{ width: "100%", borderCollapse: "collapse" }}>
            <thead>
              <tr style={{ background: C.gray50, borderBottom: `2px solid ${C.gray100}` }}>
                {["ID","Provider","Date","Time","Status","Action"].map(h => (
                  <th key={h} style={{ padding: "12px 16px", textAlign: "left", fontSize: 11, fontWeight: 700, color: C.gray600, letterSpacing: 0.5 }}>{h.toUpperCase()}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {appointments.length === 0 ? (
                <tr><td colSpan="6" style={{ padding: 40, textAlign: "center", color: C.gray400 }}>No appointments found.</td></tr>
              ) : appointments.map(a => (
                <tr key={a.appointment_id} style={{ borderBottom: `1px solid ${C.gray50}` }}>
                  <td style={{ padding: "12px 16px", fontSize: 12, color: C.gray600 }}>A-{String(a.appointment_id).slice(-4)}</td>
                  <td style={{ padding: "12px 16px" }}>
                    <div style={{ fontSize: 13, fontWeight: 600, color: C.navy }}>{role === "doctor" ? a.patient_name : a.doctor_name}</div>
                    <div style={{ fontSize: 11, color: C.gray400 }}>{role === "doctor" ? "Patient" : a.doctor_specialization}</div>
                  </td>
                  <td style={{ padding: "12px 16px", fontSize: 13, color: C.gray600 }}>{a.appointment_date}</td>
                  <td style={{ padding: "12px 16px", fontSize: 13, color: C.gray600 }}>{a.appointment_time}</td>
                  <td style={{ padding: "12px 16px" }}><Badge label={a.status} color={a.status} /></td>
                  <td style={{ padding: "12px 16px" }}>
                    {a.status === "Scheduled" && (
                      <Btn 
                        variant={role === "patient" ? "danger" : "accent"} 
                        onClick={() => updateStatus(a.appointment_id, role === "patient" ? "Cancelled" : "Completed")} 
                        style={{ padding: "5px 12px", fontSize: 11 }}
                      >
                        {role === "patient" ? <><XCircle size={12} /> Cancel</> : <><Check size={12} /> Done</>}
                      </Btn>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      {showModal && (
        <Modal title="Book New Appointment" onClose={() => setShowModal(false)}>
          <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
            <Input label="Select Doctor" value={form.doctor_id} onChange={v => setForm(f => ({ ...f, doctor_id: v }))}
              options={DOCTORS.map(d => ({ value: String(d.doctor_id), label: `${d.full_name} — ${d.specialization}` }))} />
            <Input label="Preferred Date" type="date" value={form.date} onChange={v => setForm(f => ({ ...f, date: v }))} />
            <Input label="Reason for Visit" value={form.reason} onChange={v => setForm(f => ({ ...f, reason: v }))} />

            <div>
              <label style={{ fontSize: 12, fontWeight: 700, color: C.gray600, display: "block", marginBottom: 10 }}>AVAILABLE SLOTS</label>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 8 }}>
                {TIME_SLOTS.map(slot => {
                  const isBooked = bookedSlots.includes(slot);
                  return (
                    <button key={slot} onClick={() => !isBooked && handleBook(slot)} disabled={isBooked}
                      style={{ padding: "9px 0", borderRadius: 8, border: `1.5px solid ${isBooked ? C.gray100 : C.accent}`, background: isBooked ? C.gray50 : "#EFF8FF", color: isBooked ? C.gray400 : C.accent, fontSize: 12, fontWeight: 600, cursor: isBooked ? "not-allowed" : "pointer" }}>
                      {slot}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
};


// ─── HEALTH RECORDS & MEDICATIONS (SHARED INTERFACE) ──────────────────────────
const HealthRecords = ({ auth, activeView }) => {
  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState(null);
  const [items, setItems] = useState([]);

  // Determine which tab we are currently on
  const isRecords = activeView === "records";
  const dbKey = isRecords ? "medivault_records_db" : "medivault_medications_db";
  const idField = isRecords ? "record_id" : "medication_id";

  // 1. Load Data Dynamically Based on Tab
  useEffect(() => {
    if (auth.role === "admin") return;

    const dbStr = localStorage.getItem(dbKey);
    let db = dbStr ? JSON.parse(dbStr) : [];
    
    // Seed with initial data if empty
    if (db.length === 0) {
      db = isRecords ? HEALTH_RECORDS : MEDICATIONS_INIT; 
      localStorage.setItem(dbKey, JSON.stringify(db));
    }

    // Filter items: Patients only see their own. Doctors see all.
    let visibleItems = db;
    if (auth.role === "patient") {
      visibleItems = db.filter(item => item.patient_id === auth.entity_id);
    }
    setItems(visibleItems.reverse()); // Newest first
    setSearch(""); 
    setSelected(null); 
  }, [auth.role, auth.entity_id, isRecords, dbKey]);

  // 2. SECURITY CHECK: Block Admin Access
  if (auth.role === "admin") {
    return (
      <div style={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", height: "60vh", color: C.gray600, textAlign: "center" }}>
        <Lock size={64} color={C.gray400} style={{ marginBottom: 16 }} />
        <h2 style={{ margin: "0 0 8px", color: C.navy, fontSize: 24, fontWeight: 700 }}>Access Restricted</h2>
        <p style={{ margin: 0, maxWidth: 400, lineHeight: 1.5 }}>
          Due to HIPAA compliance and patient privacy regulations, Administrators cannot view or modify clinical health records or medications.
        </p>
      </div>
    );
  }

  // 3. Handle File Upload (Now converts file to Base64 for downloading later)
  const handleFileUpload = (e) => {
    const file = e.target.files[0];
    if (!file) return;

    // Safety check: LocalStorage has a ~5MB limit. Prevent large files from crashing the demo.
    if (file.size > 2 * 1024 * 1024) {
      alert("Demo Limit: Please select a file smaller than 2MB.");
      return;
    }

    const reader = new FileReader();
    
    // When the file is done being read by the browser:
    reader.onload = (event) => {
      const fileData = event.target.result; // This is the Base64 string

      const newItem = {
        [idField]: Date.now(),
        patient_id: auth.role === "patient" ? auth.entity_id : 1, 
        doctor_id: auth.role === "doctor" ? auth.entity_id : null,
        visit_date: new Date().toISOString().split('T')[0],
        start_date: new Date().toISOString().split('T')[0],
        diagnosis: isRecords ? "Uploaded Document" : undefined,
        medicine_name: !isRecords ? "Uploaded Prescription" : undefined,
        attached_file: {
          name: file.name,
          size: (file.size / 1024 / 1024).toFixed(2) + " MB",
          type: file.type,
          data: fileData // <--- We save the actual file data here now!
        }
      };

      const dbStr = localStorage.getItem(dbKey);
      const db = dbStr ? JSON.parse(dbStr) : [];
      
      const updatedDb = [newItem, ...db];
      localStorage.setItem(dbKey, JSON.stringify(updatedDb));
      
      setItems(updatedDb.filter(r => auth.role === "doctor" || r.patient_id === auth.entity_id));
      alert(`Successfully uploaded: ${file.name}`);
    };

    // Trigger the file read
    reader.readAsDataURL(file);
  };

  // 4. Handle Deleting an Uploaded File
  const handleDeleteFile = (itemId, e) => {
    e.stopPropagation(); 
    
    if (window.confirm("Are you sure you want to permanently delete this file? This action cannot be undone.")) {
      const dbStr = localStorage.getItem(dbKey);
      const db = dbStr ? JSON.parse(dbStr) : [];
      
      const updatedDb = db.filter(item => item[idField] !== itemId);
      localStorage.setItem(dbKey, JSON.stringify(updatedDb));
      
      setItems(items.filter(item => item[idField] !== itemId));
      if (selected === itemId) setSelected(null);
    }
  };

  // 5. Handle Downloading a File
  const handleDownload = (fileObj, e) => {
    e.stopPropagation();
    
    if (!fileObj.data) {
      alert("This is a legacy dummy file without actual data. Please upload a new file to test the download feature!");
      return;
    }

    // Create an invisible HTML link, set it to the file data, and force a click
    const link = document.createElement("a");
    link.href = fileObj.data;
    link.download = fileObj.name; // This tells the browser what to name the downloaded file
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Dynamic Search Filter
  const filteredItems = items.filter(item => {
    const s = search.toLowerCase();
    if (item.attached_file) return item.attached_file.name.toLowerCase().includes(s);
    if (isRecords) return (item.diagnosis || "").toLowerCase().includes(s) || (item.lab_reports || "").toLowerCase().includes(s);
    return (item.medicine_name || "").toLowerCase().includes(s) || (item.dosage || "").toLowerCase().includes(s);
  });

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
      {/* Dynamic Header & Upload Controls */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div>
          <h2 style={{ margin: 0, color: C.navy, fontSize: 20, fontWeight: 700 }}>
            {isRecords ? "Health Records & Reports" : "Active & Past Medications"}
          </h2>
          <p style={{ margin: "4px 0 0", color: C.gray600, fontSize: 13 }}>
            {isRecords ? "Manage your lab reports, visit notes, and test results" : "Track your prescriptions, dosages, and daily medication schedule"}
          </p>
        </div>
        
        <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
          <div style={{ position: "relative" }}>
            <Search size={16} color={C.gray400} style={{ position: "absolute", left: 10, top: "50%", transform: "translateY(-50%)" }} />
            <input 
              type="text" 
              placeholder={`Search ${isRecords ? "records" : "medications"}...`}
              value={search} 
              onChange={e => setSearch(e.target.value)}
              style={{ padding: "8px 12px 8px 34px", border: `1.5px solid ${C.gray100}`, borderRadius: 8, fontSize: 13, width: 220, outline: "none", color: C.navy }} 
            />
          </div>

          <input type="file" id="file-upload" style={{ display: "none" }} onChange={handleFileUpload} accept=".pdf,.png,.jpg,.jpeg,.doc,.docx" />
          <label htmlFor="file-upload">
            <div style={{ display: "flex", alignItems: "center", gap: 6, background: C.accent, color: "#fff", padding: "8px 16px", borderRadius: 8, fontSize: 13, fontWeight: 600, cursor: "pointer", transition: "opacity 0.2s" }} onMouseOver={e => e.currentTarget.style.opacity = 0.9} onMouseOut={e => e.currentTarget.style.opacity = 1}>
              <Upload size={16} /> {isRecords ? "Upload Report" : "Upload Script"}
            </div>
          </label>
        </div>
      </div>

      {/* Dynamic List */}
      <div style={{ display: "grid", gap: 12 }}>
        {filteredItems.length === 0 ? (
          <div style={{ padding: 40, textAlign: "center", color: C.gray400, fontSize: 14 }}>
            {isRecords ? "No health records found." : "No medications found."}
          </div>
        ) : filteredItems.map(item => {
          const id = item[idField];
          const title = item.attached_file ? item.attached_file.name : (isRecords ? item.diagnosis : item.medicine_name);
          const subtitle = isRecords ? `Date: ${item.visit_date}` : `Started: ${item.start_date || item.visit_date} ${item.dosage ? `· Dosage: ${item.dosage}` : ""}`;
          const isUploaded = !!item.attached_file;

          return (
            <Card key={id} style={{ padding: 16 }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                  <div style={{ background: isUploaded ? "#EFF8FF" : (isRecords ? C.gray50 : "#ECFDF5"), padding: 10, borderRadius: 8 }}>
                    {isUploaded ? <FileText size={20} color={C.accent} /> : (isRecords ? <Activity size={20} color={C.navyLight} /> : <Pill size={20} color={C.green} />)}
                  </div>
                  <div>
                    <div style={{ fontWeight: 700, color: C.navy, fontSize: 15 }}>{title}</div>
                    <div style={{ color: C.gray600, fontSize: 12, marginTop: 4 }}>
                      {subtitle} {isUploaded && `· Size: ${item.attached_file.size}`}
                    </div>
                  </div>
                </div>
                
                {/* Action Buttons */}
                <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
                  {isUploaded && (auth.role === "doctor" || item.patient_id === auth.entity_id) && (
                    <button 
                      onClick={(e) => handleDeleteFile(id, e)} title="Delete File"
                      style={{ background: "#FEF2F2", border: "none", color: C.red, padding: "8px", borderRadius: 6, cursor: "pointer", display: "flex", alignItems: "center", transition: "background 0.2s" }}
                      onMouseOver={e => e.currentTarget.style.background = "#FEE2E2"} onMouseOut={e => e.currentTarget.style.background = "#FEF2F2"}
                    >
                      <Trash2 size={16} />
                    </button>
                  )}
                  <Btn variant="ghost" onClick={() => setSelected(selected === id ? null : id)}>
                    {selected === id ? "Close" : "View Details"}
                  </Btn>
                </div>
              </div>
              
              {/* Expanded Details */}
              {selected === id && (
                <div style={{ marginTop: 16, padding: 16, background: C.gray50, borderRadius: 8, fontSize: 13, color: C.navy, border: `1px solid ${C.gray100}` }}>
                  {isUploaded ? (
                     <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                       <strong>Document Details:</strong>
                       <div>Type: {item.attached_file.type || "Unknown Document"}</div>
                       <div>Uploaded By: {item.doctor_id ? "Medical Staff" : "Patient"}</div>
                       
                       {/* THE NEW DOWNLOAD BUTTON */}
                       <Btn variant="primary" style={{ width: "fit-content", marginTop: 8 }} onClick={(e) => handleDownload(item.attached_file, e)}>
                         <Download size={14}/> Download File
                       </Btn>

                     </div>
                  ) : isRecords ? (
                    <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                      <div><strong>Diagnosis / Reason:</strong> {item.diagnosis}</div>
                      <div><strong>Prescription Notes:</strong> {item.prescription}</div>
                      <div><strong>Lab Reports:</strong> {item.lab_reports}</div>
                      {item.follow_up_date && <div><strong>Follow-up:</strong> {item.follow_up_date}</div>}
                    </div>
                  ) : (
                    <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                      <div><strong>Medication:</strong> {item.medicine_name}</div>
                      <div><strong>Dosage & Frequency:</strong> {item.dosage} — {item.frequency}</div>
                      <div><strong>Duration:</strong> {item.start_date} to {item.end_date || "Ongoing"}</div>
                      {item.reminder_time && <div><strong>Daily Reminder Scheduled:</strong> {item.reminder_time}</div>}
                    </div>
                  )}
                </div>
              )}
            </Card>
          );
        })}
      </div>
    </div>
  );
};

/// ─── DOCTOR DASHBOARD ─────────────────────────────────────────────────────────
const DoctorDashboard = ({ auth, setActive }) => {
  const [stats, setStats] = useState({ queue: 0, patients: 0, reports: 0 });
  const [dailyQueue, setDailyQueue] = useState([]);

  useEffect(() => {
    const drId = auth.entity_id;

    // 1. Get Doctor's Specific Queue
    const appts = JSON.parse(localStorage.getItem("medivault_appointments_db") || "[]");
    const myQueue = appts.filter(a => a.doctor_id === drId && a.status === "Scheduled");

    // 2. Calculate Unique Patients seen by this Doctor
    const uniquePatients = [...new Set(appts.filter(a => a.doctor_id === drId).map(a => a.patient_id))];

    // 3. Get Reports review count
    const records = JSON.parse(localStorage.getItem("medivault_records_db") || "[]");
    const myRecords = records.filter(r => r.doctor_id === drId);

    setStats({
      queue: myQueue.length,
      patients: uniquePatients.length,
      reports: myRecords.length
    });
    setDailyQueue(myQueue.slice(0, 3));
  }, [auth.entity_id]);

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 24 }}>
      <div style={{ background: `linear-gradient(120deg, ${C.navy} 0%, ${C.accent} 100%)`, borderRadius: 14, padding: "24px 28px", color: "#fff" }}>
        <div style={{ fontSize: 12, opacity: 0.7, marginBottom: 4 }}>CLINICAL OVERVIEW</div>
        <div style={{ fontSize: 24, fontWeight: 700 }}>{auth.user_info?.full_name}</div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))", gap: 16 }}>
        <Stat icon={Users} label="My Patients" value={stats.patients} sub="Lifetime" accent={C.accent} onClick={() => setActive('patients')} />
        <Stat icon={Calendar} label="Queue Today" value={stats.queue} sub="Pending Consults" accent={C.navyLight} onClick={() => setActive('appointments')} />
        <Stat icon={ClipboardList} label="Reports" value={stats.reports} sub="Reviews Filed" accent={C.gold} onClick={() => setActive('records')} />
        <Stat icon={Activity} label="System" value="Stable" sub="Cloud Sync Active" accent={C.green} />
      </div>

      <Card style={{ padding: 22 }}>
        <h3 style={{ margin: "0 0 16px", color: C.navy, fontSize: 16, fontWeight: 700 }}>Next Appointments</h3>
        {dailyQueue.length === 0 ? (
          <div style={{ color: C.gray400, fontSize: 13, textAlign: "center", padding: "20px 0" }}>Your queue is currently empty.</div>
        ) : dailyQueue.map(a => (
          <div key={a.appointment_id} style={{ display: "flex", justifyContent: "space-between", padding: "12px 0", borderBottom: `1px solid ${C.gray50}` }}>
            <div>
              <div style={{ fontWeight: 600, color: C.navy, fontSize: 14 }}>{a.patient_name}</div>
              <div style={{ color: C.gray400, fontSize: 11 }}>{a.notes || "General Consultation"}</div>
            </div>
            <div style={{ textAlign: "right" }}>
              <div style={{ color: C.accent, fontWeight: 700, fontSize: 13 }}>{a.appointment_time}</div>
              <div style={{ color: C.gray400, fontSize: 11 }}>{a.appointment_date}</div>
            </div>
          </div>
        ))}
      </Card>
    </div>
  );
};
  
/// ─── ADMIN DASHBOARD (WITH ERROR HANDLING) ────────────────────────────────────
const AdminDashboard = ({ auth, setActive }) => {
  const [stats, setStats] = useState({ users: 0, patients: 0, doctors: 0, appointments: 0 });
  const [apiError, setApiError] = useState("");
  const [staffName, setStaffName] = useState("");
  const [staffEmail, setStaffEmail] = useState("");
  const [staffRole, setStaffRole] = useState("doctor");
  const [staffSpec, setStaffSpec] = useState("");
  const [provMsg, setProvMsg] = useState("");
  
  // 1. fetchStats is safely defined at the top so the whole component can use it!
  const fetchStats = async () => {
    try {
      const response = await fetch(`${API_URL}/admin/stats`, {
        headers: { "Authorization": `Bearer ${auth.access_token}` }
      });
      
      if (response.ok) {
        const data = await response.json();
        setStats(data);
        setApiError(""); 
      } else {
        const errData = await response.json();
        setApiError(`Access Denied: ${errData.error || response.statusText}`);
      }
    } catch (err) {
      setApiError("Network Error: Could not reach the Python server.");
      console.error("Failed to fetch admin stats:", err);
    }
  };

  // 2. It runs automatically when the dashboard first loads
  useEffect(() => {
    fetchStats();
  }, [auth.access_token]);

  // 3. It runs AGAIN when you click "Create Account" to refresh the numbers
  const handleCreateStaff = async () => {
    setProvMsg("Provisioning...");
    try {
      const response = await fetch(`${API_URL}/admin/create-staff`, {
        method: "POST",
        headers: { 
          "Content-Type": "application/json",
          "Authorization": `Bearer ${auth.access_token}` 
        },
        body: JSON.stringify({
          full_name: staffName,
          email: staffEmail,
          role: staffRole,
          specialization: staffRole === 'doctor' ? staffSpec : null
        })
      });
      
      const data = await response.json();
      if (response.ok) {
        setProvMsg(`✅ ${data.message}`);
        setStaffName(""); setStaffEmail(""); setStaffSpec("");
        fetchStats(); // <--- THIS KEEPS EVERYTHING IN SYNC!
      } else {
        setProvMsg(`❌ ${data.error || data.msg || "Unknown error occurred"}`);
      }
    } catch (err) {
      setProvMsg("❌ Server error.");
    }
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 24 }}>
      {/* Banner */}
      <div style={{ background: `linear-gradient(120deg, ${C.gray800} 0%, ${C.navy} 100%)`, borderRadius: 14, padding: "24px 28px", color: "#fff", boxShadow: "0 4px 12px rgba(30,41,59,0.2)" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <div>
            <div style={{ color: "rgba(255,255,255,0.6)", fontSize: 12, marginBottom: 4, letterSpacing: 0.5, fontWeight: 600 }}>SYSTEM CONTROL</div>
            <div style={{ fontSize: 24, fontWeight: 700 }}>Administrator Console</div>
            <div style={{ color: "rgba(255,255,255,0.7)", fontSize: 13, marginTop: 6 }}>Manage hospital operations, users, and security configurations.</div>
          </div>
          <Shield size={48} color="rgba(255,255,255,0.1)" />
        </div>
      </div>

      {/* ERROR BANNER */}
      {apiError && (
        <div style={{ background: "#FEF2F2", border: `1px solid ${C.red}`, color: C.red, padding: "12px 16px", borderRadius: 8, fontSize: 13, display: "flex", alignItems: "center", gap: 8, fontWeight: 600 }}>
          <AlertTriangle size={18} /> {apiError}
        </div>
      )}

      {/* Interactive Stats Grid */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))", gap: 16 }}>
        <Stat icon={Users} label="Total Users" value={stats.users} sub={`${stats.patients} Patients`} accent={C.accent} onClick={() => setActive('users')} />
        <Stat icon={Stethoscope} label="Medical Staff" value={stats.doctors} sub="Active Doctors" accent={C.navyLight} onClick={() => setActive('users')} />
        <Stat icon={Calendar} label="Appointments" value={stats.appointments} sub="System-wide" accent={C.green} onClick={() => setActive('appointments')} />
        <Stat icon={Database} label="System Health" value="100%" sub="All systems operational" accent={C.gold} onClick={() => setActive('settings')} />
      </div>

      {/* --- ADMIN STAFF PROVISIONING CARD --- */}
      <Card style={{ padding: 24, marginBottom: 24 }}>
        <h3 style={{ margin: "0 0 16px", color: C.navy, fontSize: 18 }}>➕ Provision New Staff Member</h3>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
          
          <Input label="Staff Full Name" value={staffName} onChange={setStaffName} />
          <Input label="Official Email Address" value={staffEmail} onChange={setStaffEmail} type="email" />
          
          <Input label="System Role" value={staffRole} onChange={setStaffRole} options={[
            {value: "doctor", label: "Medical Professional (Doctor)"},
            {value: "admin", label: "System Administrator"}
          ]} />
          
          {staffRole === "doctor" && (
            <Input label="Medical Specialization" value={staffSpec} onChange={setStaffSpec} placeholder="e.g., Neurology, Pediatrics" />
          )}
          
        </div>
        
        <div style={{ display: "flex", alignItems: "center", gap: 16, marginTop: 16 }}>
          <Btn onClick={handleCreateStaff} style={{ padding: "8px 16px" }}>Create Account</Btn>
          {provMsg && <span style={{ fontSize: 13, fontWeight: 600, color: provMsg.includes("✅") ? C.green : C.red }}>{provMsg}</span>}
        </div>
      </Card>

      <div style={{ padding: 22, background: C.gray800, color: "#fff", borderRadius: 12, marginTop: 20 }}>
          <h3 style={{ margin: "0 0 16px", color: "#fff", fontSize: 15, fontWeight: 700 }}>Live System Logs</h3>
          <div style={{ fontFamily: "monospace", fontSize: 12, color: C.green, display: "flex", flexDirection: "column", gap: 8, opacity: 0.8 }}>
            <div>{">"} [DB] Successfully connected to MySQL healthcare_db</div>
            <div>{">"} [API] Admin stats synced successfully.</div>
            <div style={{ color: C.accentLight, marginTop: 4 }}>_ waiting for new events...</div>
          </div>
      </div>
    </div>
  );
};

// ─── ADMIN: USER MANAGEMENT ───────────────────────────────────────────────────
const AdminUsers = ({ auth }) => { // Ensure auth prop is passed here
  const [searchTerm, setSearchTerm] = useState("");
  const [usersList, setUsersList] = useState([]);
  const [loading, setLoading] = useState(true);

  const [msgModal, setMsgModal] = useState({ isOpen: false, user: null, text: "" });

  // FETCH USERS FROM SQL
  const fetchUsers = async () => {
    try {
      const response = await fetch(`${API_URL}/admin/users`, {
        headers: { "Authorization": `Bearer ${auth.access_token}` }
      });
      if (response.ok) {
        const data = await response.json();
        setUsersList(data);
      }
    } catch (err) {
      console.error("Failed to sync users:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUsers();
  }, [auth.access_token]);


  // Load users from the Mock Database when the page opens
  useEffect(() => {
    const dbStr = localStorage.getItem("medivault_users_db");
    let db = dbStr ? JSON.parse(dbStr) : [];
    
    // Seed with demo data if empty so the admin has something to manage
    if (db.length === 0) {
      db = [
        ...PATIENTS.map(p => ({ id: p.patient_id, email: "patient@demo.com", role: "patient", info: p, status: "Active" })),
        ...DOCTORS.map(d => ({ id: d.doctor_id, email: "doctor@demo.com", role: "doctor", info: d, status: "Active" }))
      ];
      localStorage.setItem("medivault_users_db", JSON.stringify(db));
    }
    setUsersList(db);
  }, []);

  // --- ADMIN SUPERPOWERS --- //

  // 1. Toggle Suspend/Active Status
  const handleToggleStatus = (userId) => {
    const updatedUsers = usersList.map(u => {
      if (u.id === userId) {
        return { ...u, status: u.status === "Suspended" ? "Active" : "Suspended" };
      }
      return u;
    });
    setUsersList(updatedUsers);
    localStorage.setItem("medivault_users_db", JSON.stringify(updatedUsers));
  };

  // 2. Delete User
  const handleDeleteUser = (userId) => {
    // Safety confirmation prompt
    if (window.confirm("CRITICAL WARNING: Are you sure you want to permanently delete this user? This cannot be undone.")) {
      const updatedUsers = usersList.filter(u => u.id !== userId);
      setUsersList(updatedUsers);
      localStorage.setItem("medivault_users_db", JSON.stringify(updatedUsers));
    }
  };

 // 3. Send Message (Inside AdminUsers)
  const handleSendMessage = () => {
    if (!msgModal.text.trim()) return;
    
    // Pull the existing messages database (or create a new array if empty)
    const msgsStr = localStorage.getItem("medivault_messages_db");
    const msgsDb = msgsStr ? JSON.parse(msgsStr) : [];
    
    // Create the new message object
    const newMessage = {
      id: 'msg_' + Date.now(),
      to_user_id: msgModal.user.id, // Target the specific user
      sender: "System Admin",
      time: "Just now",
      text: msgModal.text,
      read: false
    };
    
    // Save it to LocalStorage
    msgsDb.push(newMessage);
    localStorage.setItem("medivault_messages_db", JSON.stringify(msgsDb));
    
    alert(`[SYSTEM] Message successfully routed to ${msgModal.user.email}`);
    setMsgModal({ isOpen: false, user: null, text: "" }); // Close modal
  };

  // Filter for search bar
  const filteredUsers = usersList.filter(u => 
    u.info?.full_name?.toLowerCase().includes(searchTerm.toLowerCase()) || 
    u.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div>
          <h2 style={{ margin: 0, color: C.navy, fontSize: 20, fontWeight: 700 }}>User Management</h2>
          <p style={{ margin: "4px 0 0", color: C.gray600, fontSize: 13 }}>Enforce policies, manage access, and message users</p>
        </div>
        <div style={{ position: "relative" }}>
          <Search size={16} color={C.gray400} style={{ position: "absolute", left: 10, top: "50%", transform: "translateY(-50%)" }} />
          <input 
            type="text" placeholder="Search by name or email..." value={searchTerm} onChange={e => setSearchTerm(e.target.value)}
            style={{ padding: "8px 12px 8px 34px", border: `1.5px solid ${C.gray100}`, borderRadius: 8, fontSize: 13, outline: "none", width: 280, color: C.navy }} 
          />
        </div>
      </div>

      <Card style={{ overflowX: "auto", padding: 0 }}>
        <table style={{ width: "100%", borderCollapse: "collapse" }}>
          <thead>
            <tr style={{ background: C.gray50, borderBottom: `2px solid ${C.gray100}` }}>
              {["User", "Role", "Contact Info", "System Status", "Admin Actions"].map(h => (
                <th key={h} style={{ padding: "14px 20px", textAlign: "left", fontSize: 11, fontWeight: 700, color: C.gray600, letterSpacing: 0.5, textTransform: "uppercase", whiteSpace: "nowrap" }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {filteredUsers.length === 0 ? (
              <tr>
                <td colSpan="5" style={{ padding: 40, textAlign: "center", color: C.gray400 }}>No users found matching your search.</td>
              </tr>
            ) : (
              filteredUsers.map((u, i) => (
                <tr key={u.id || i} style={{ borderBottom: `1px solid ${C.gray50}`, transition: "background 0.2s", opacity: u.status === "Suspended" ? 0.6 : 1 }} onMouseOver={e => e.currentTarget.style.background = C.gray50} onMouseOut={e => e.currentTarget.style.background = "transparent"}>
                  <td style={{ padding: "14px 20px" }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                      <div style={{ width: 36, height: 36, borderRadius: "50%", background: u.role === "doctor" ? C.navyLight : u.role === "admin" ? C.gray800 : C.accentLight, display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontWeight: 700, fontSize: 14 }}>
                        {u.info?.full_name?.charAt(0) || "U"}
                      </div>
                      <div>
                        <div style={{ fontWeight: 600, color: C.navy, fontSize: 14 }}>{u.info?.full_name || "Unknown"}</div>
                        <div style={{ color: C.gray400, fontSize: 11, marginTop: 2 }}>ID: {u.id}</div>
                      </div>
                    </div>
                  </td>
                  <td style={{ padding: "14px 20px" }}>
                    <Badge label={u.role} color={u.role === "doctor" ? "Scheduled" : u.role === "admin" ? "Cancelled" : "Completed"} />
                  </td>
                  <td style={{ padding: "14px 20px" }}>
                    <div style={{ color: C.navy, fontSize: 13 }}>{u.email}</div>
                    <div style={{ color: C.gray400, fontSize: 11, marginTop: 2 }}>{u.info?.phone || "No phone"}</div>
                  </td>
                  <td style={{ padding: "14px 20px" }}>
                    <Badge label={u.status || "Active"} color={u.status === "Suspended" ? "Cancelled" : "Active"} />
                  </td>
                  <td style={{ padding: "14px 20px" }}>
                    <div style={{ display: "flex", gap: 8 }}>
                      {/* Message Button */}
                      <button onClick={() => setMsgModal({ isOpen: true, user: u, text: "" })} title="Send Message" style={{ padding: 6, background: "#EFF8FF", color: C.accent, border: "none", borderRadius: 6, cursor: "pointer" }}><Mail size={16} /></button>
                      
                      {/* Prevent Admins from deleting/suspending other Admins easily */}
                      {u.role !== "admin" && (
                        <>
                          <button onClick={() => handleToggleStatus(u.id)} title={u.status === "Suspended" ? "Reactivate User" : "Suspend User"} style={{ padding: 6, background: "#FFFBEB", color: C.amber, border: "none", borderRadius: 6, cursor: "pointer" }}><AlertTriangle size={16} /></button>
                          <button onClick={() => handleDeleteUser(u.id)} title="Delete User" style={{ padding: 6, background: "#FEF2F2", color: C.red, border: "none", borderRadius: 6, cursor: "pointer" }}><XCircle size={16} /></button>
                        </>
                      )}
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </Card>

      {/* Message Composition Modal */}
      {msgModal.isOpen && (
        <Modal title={`Message ${msgModal.user?.info?.full_name}`} onClose={() => setMsgModal({ isOpen: false, user: null, text: "" })}>
          <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
            <div style={{ background: C.gray50, padding: 12, borderRadius: 8, fontSize: 12, color: C.gray600 }}>
              <strong>To:</strong> {msgModal.user?.email} <br/>
              <strong>Role:</strong> {msgModal.user?.role.toUpperCase()}
            </div>
            
            <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
              <label style={{ fontSize: 12, fontWeight: 700, color: C.gray600 }}>MESSAGE BODY</label>
              <textarea 
                rows="5"
                placeholder="Type your official system message here..."
                value={msgModal.text}
                onChange={(e) => setMsgModal(prev => ({ ...prev, text: e.target.value }))}
                style={{ border: `1.5px solid ${C.gray100}`, borderRadius: 8, padding: "12px", fontSize: 13, color: C.navy, outline: "none", resize: "none", fontFamily: "inherit" }}
              />
            </div>

            <div style={{ display: "flex", justifyContent: "flex-end", gap: 12, marginTop: 8 }}>
              <Btn variant="ghost" onClick={() => setMsgModal({ isOpen: false, user: null, text: "" })}>Cancel</Btn>
              <Btn variant="primary" onClick={handleSendMessage} disabled={!msgModal.text.trim()}><Mail size={16} /> Send Message</Btn>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
};

// ─── ADMIN: ANALYTICS ─────────────────────────────────────────────────────────
const AdminAnalytics = () => (
  <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
    <div>
      <h2 style={{ margin: 0, color: C.navy, fontSize: 20, fontWeight: 700 }}>Hospital Analytics</h2>
      <p style={{ margin: "4px 0 0", color: C.gray600, fontSize: 13 }}>Performance metrics and system utilization</p>
    </div>

    <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 20 }}>
      <Card style={{ padding: 24, display: "flex", flexDirection: "column", gap: 16 }}>
        <div style={{ display: "flex", justifyContent: "space-between" }}>
          <div style={{ fontWeight: 600, color: C.navy, fontSize: 14 }}>Patient Retention</div>
          <TrendingUp size={18} color={C.green} />
        </div>
        <div style={{ fontSize: 32, fontWeight: 800, color: C.navy }}>84.2%</div>
        <div style={{ background: C.gray100, height: 6, borderRadius: 3, overflow: "hidden" }}>
          <div style={{ background: C.green, width: "84.2%", height: "100%" }} />
        </div>
      </Card>

      <Card style={{ padding: 24, display: "flex", flexDirection: "column", gap: 16 }}>
        <div style={{ display: "flex", justifyContent: "space-between" }}>
          <div style={{ fontWeight: 600, color: C.navy, fontSize: 14 }}>Server Uptime</div>
          <Activity size={18} color={C.accent} />
        </div>
        <div style={{ fontSize: 32, fontWeight: 800, color: C.navy }}>99.9%</div>
        <div style={{ background: C.gray100, height: 6, borderRadius: 3, overflow: "hidden" }}>
          <div style={{ background: C.accent, width: "99.9%", height: "100%" }} />
        </div>
      </Card>

      <Card style={{ padding: 24, display: "flex", flexDirection: "column", gap: 16 }}>
        <div style={{ display: "flex", justifyContent: "space-between" }}>
          <div style={{ fontWeight: 600, color: C.navy, fontSize: 14 }}>Avg Wait Time</div>
          <Clock size={18} color={C.amber} />
        </div>
        <div style={{ fontSize: 32, fontWeight: 800, color: C.navy }}>14 mins</div>
        <div style={{ background: C.gray100, height: 6, borderRadius: 3, overflow: "hidden" }}>
          <div style={{ background: C.amber, width: "40%", height: "100%" }} />
        </div>
      </Card>
    </div>

    <Card style={{ padding: 24, minHeight: 300, display: "flex", alignItems: "center", justifyContent: "center", flexDirection: "column", color: C.gray400 }}>
      <BarChart2 size={48} style={{ opacity: 0.2, marginBottom: 16 }} />
      <div style={{ fontSize: 16, fontWeight: 600, color: C.navy }}>Advanced Charts Module</div>
      <div style={{ fontSize: 13 }}>Connect a charting library (like Chart.js) to render full graphical data here.</div>
    </Card>
  </div>
);

// ─── ADMIN: SYSTEM CONFIGURATION ──────────────────────────────────────────────
const AdminSettings = () => (
  <div style={{ display: "flex", flexDirection: "column", gap: 20, maxWidth: 800 }}>
    <div>
      <h2 style={{ margin: 0, color: C.navy, fontSize: 20, fontWeight: 700 }}>System Configuration</h2>
      <p style={{ margin: "4px 0 0", color: C.gray600, fontSize: 13 }}>Manage global variables and hospital-wide settings</p>
    </div>

    <Card style={{ padding: 24 }}>
      <h3 style={{ margin: "0 0 20px", color: C.navy, fontSize: 15, fontWeight: 700, borderBottom: `1px solid ${C.gray50}`, paddingBottom: 12 }}>Global Settings</h3>
      <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
        <Input label="Hospital Name" value="Medi Vault HMS" onChange={() => {}} />
        <Input label="Support Email Route" value="support@medivault.com" onChange={() => {}} />
        <Input label="System Maintenance Mode" type="text" options={["Disabled (Live)", "Enabled (Offline)"]} value="Disabled (Live)" onChange={() => {}} />
      </div>
    </Card>

    <Card style={{ padding: 24 }}>
      <h3 style={{ margin: "0 0 20px", color: C.navy, fontSize: 15, fontWeight: 700, borderBottom: `1px solid ${C.gray50}`, paddingBottom: 12 }}>Appointment Parameters</h3>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
        <Input label="Consultation Duration (mins)" type="number" value="30" onChange={() => {}} />
        <Input label="Max Appointments Per Doctor/Day" type="number" value="24" onChange={() => {}} />
      </div>
    </Card>

    <div style={{ display: "flex", justifyContent: "flex-end", gap: 12 }}>
      <Btn variant="outline">Discard Changes</Btn>
      <Btn variant="accent"><Check size={16} /> Save Configuration</Btn>
    </div>
  </div>
);


// ─── USER PROFILE ─────────────────────────────────────────────────────────────
const UserProfile = ({ auth }) => {
  const [isEditing, setIsEditing] = useState(false);
  
  // Initialize form state with the user's current data
  const [formData, setFormData] = useState({
    full_name: auth.user_info?.full_name || "",
    phone: auth.user_info?.phone || "",
    address: auth.user_info?.address || "",
    emergency_contact: auth.user_info?.emergency_contact || "",
    email: auth.user_info?.email || "user@medivault.com", // Fallback if email isn't in user_info
    blood_group: auth.user_info?.blood_group || "N/A",
  });

  const handleSave = () => {
    // In a real app, you would make a fetch() PUT request here
    console.log("Saving new data:", formData);
    setIsEditing(false);
  };

  const isDoctor = auth.role === "doctor";

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 24, maxWidth: 900 }}>
      {/* Header Banner */}
      <Card style={{ padding: "32px", display: "flex", gap: 24, alignItems: "center", background: `linear-gradient(135deg, ${C.navy} 0%, ${C.navyMid} 100%)`, color: "#fff", border: "none" }}>
        <div style={{ width: 80, height: 80, borderRadius: "50%", background: C.gold, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 32, fontWeight: 700, color: C.navy, flexShrink: 0, border: "4px solid rgba(255,255,255,0.2)" }}>
          {formData.full_name?.charAt(0)}
        </div>
        <div style={{ flex: 1 }}>
          <h2 style={{ margin: "0 0 4px", fontSize: 24, fontWeight: 700 }}>{formData.full_name}</h2>
          <div style={{ color: "rgba(255,255,255,0.7)", fontSize: 14 }}>
            {auth.role.toUpperCase()} PORTAL · ID: {isDoctor ? `D-${auth.entity_id}` : `P-${auth.entity_id}`}
          </div>
        </div>
        <Btn variant={isEditing ? "accent" : "outline"} style={{ borderColor: "rgba(255,255,255,0.3)", color: "#fff" }} onClick={() => isEditing ? handleSave() : setIsEditing(true)}>
          {isEditing ? <><Check size={16} /> Save Changes</> : <><Edit size={16} /> Edit Profile</>}
        </Btn>
      </Card>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))", gap: 24 }}>
        {/* Contact Information */}
        <Card style={{ padding: 24 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 20, color: C.navy, borderBottom: `1px solid ${C.gray50}`, paddingBottom: 12 }}>
            <User size={18} />
            <h3 style={{ margin: 0, fontSize: 15, fontWeight: 700 }}>Contact Details</h3>
          </div>
          
          <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
            {isEditing ? (
              <>
                <Input label="Full Name" value={formData.full_name} onChange={v => setFormData({ ...formData, full_name: v })} />
                <Input label="Email Address" value={formData.email} onChange={v => setFormData({ ...formData, email: v })} />
                <Input label="Phone Number" value={formData.phone} onChange={v => setFormData({ ...formData, phone: v })} />
                <Input label="Residential Address" value={formData.address} onChange={v => setFormData({ ...formData, address: v })} />
              </>
            ) : (
              <>
                <div style={{ display: "flex", gap: 12, alignItems: "flex-start" }}>
                  <Mail size={16} color={C.gray400} style={{ marginTop: 2 }} />
                  <div>
                    <div style={{ fontSize: 11, color: C.gray400, fontWeight: 600 }}>EMAIL</div>
                    <div style={{ fontSize: 14, color: C.navy, marginTop: 2 }}>{formData.email}</div>
                  </div>
                </div>
                <div style={{ display: "flex", gap: 12, alignItems: "flex-start" }}>
                  <Phone size={16} color={C.gray400} style={{ marginTop: 2 }} />
                  <div>
                    <div style={{ fontSize: 11, color: C.gray400, fontWeight: 600 }}>PHONE</div>
                    <div style={{ fontSize: 14, color: C.navy, marginTop: 2 }}>+91 {formData.phone || "Not provided"}</div>
                  </div>
                </div>
                <div style={{ display: "flex", gap: 12, alignItems: "flex-start" }}>
                  <MapPin size={16} color={C.gray400} style={{ marginTop: 2 }} />
                  <div>
                    <div style={{ fontSize: 11, color: C.gray400, fontWeight: 600 }}>ADDRESS</div>
                    <div style={{ fontSize: 14, color: C.navy, marginTop: 2, lineHeight: 1.4 }}>{formData.address || "Not provided"}</div>
                  </div>
                </div>
              </>
            )}
          </div>
        </Card>

        {/* Medical / Professional Information */}
        <Card style={{ padding: 24 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 20, color: C.navy, borderBottom: `1px solid ${C.gray50}`, paddingBottom: 12 }}>
            <Activity size={18} />
            <h3 style={{ margin: 0, fontSize: 15, fontWeight: 700 }}>
              {isDoctor ? "Professional Details" : "Medical Details"}
            </h3>
          </div>

          <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
            {!isDoctor ? (
              // PATIENT VIEW
              <>
                <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
                  <Droplet size={16} color={C.red} />
                  <div>
                    <div style={{ fontSize: 11, color: C.gray400, fontWeight: 600 }}>BLOOD GROUP</div>
                    <div style={{ fontSize: 14, color: C.navy, fontWeight: 600 }}>{formData.blood_group}</div>
                  </div>
                </div>
                <div style={{ display: "flex", gap: 12, alignItems: "flex-start" }}>
                  <AlertTriangle size={16} color={C.amber} style={{ marginTop: 2 }} />
                  <div style={{ width: "100%" }}>
                    <div style={{ fontSize: 11, color: C.gray400, fontWeight: 600 }}>EMERGENCY CONTACT</div>
                    {isEditing ? (
                       <div style={{ marginTop: 4 }}>
                         <Input value={formData.emergency_contact} onChange={v => setFormData({ ...formData, emergency_contact: v })} />
                       </div>
                    ) : (
                      <div style={{ fontSize: 14, color: C.navy, marginTop: 2 }}>{formData.emergency_contact || "Not provided"}</div>
                    )}
                  </div>
                </div>
              </>
            ) : (
              // DOCTOR VIEW
              <>
                <div>
                  <div style={{ fontSize: 11, color: C.gray400, fontWeight: 600 }}>SPECIALIZATION</div>
                  <div style={{ fontSize: 14, color: C.navy, marginTop: 2 }}>{auth.user_info.specialization}</div>
                </div>
                <div>
                  <div style={{ fontSize: 11, color: C.gray400, fontWeight: 600 }}>QUALIFICATION</div>
                  <div style={{ fontSize: 14, color: C.navy, marginTop: 2 }}>{auth.user_info.qualification}</div>
                </div>
                <div>
                  <div style={{ fontSize: 11, color: C.gray400, fontWeight: 600 }}>REGISTRATION NO.</div>
                  <div style={{ fontSize: 14, color: C.navy, marginTop: 2, fontFamily: "monospace" }}>{auth.user_info.registration_no}</div>
                </div>
              </>
            )}
          </div>
        </Card>
      </div>
    </div>
  );
};

// ─── MESSAGES & NOTIFICATIONS ─────────────────────────────────────────────────
const MessagesCenter = ({ role, auth }) => {
  const [activeTab, setActiveTab] = useState("messages");
  
  // Chat UI States
  const [activeChat, setActiveChat] = useState(null); // The email of the person you are chatting with
  const [chatInput, setChatInput] = useState("");
  
  const [composeModal, setComposeModal] = useState(false);
  const [composeTo, setComposeTo] = useState("");
  const [directory, setDirectory] = useState([]);

  const [notifications, setNotifications] = useState([
    { id: 'n1', title: "Appointment Reminder", time: "10 mins ago", text: "Your checkup is tomorrow at 10:00 AM.", type: "alert", read: false },
    { id: 'n2', title: "System Update", time: "2 hours ago", text: "The hospital portal will be down for maintenance at midnight.", type: "info", read: false }
  ]);

  const [messages, setMessages] = useState([]);

  // Resolve current user data
  const myEmail = auth.email || auth.user_info?.email || (auth.role === 'patient' ? "arjun.sharma@email.com" : auth.role === 'doctor' ? "dr.mehta@hospital.com" : "admin@hospital.com");
  const myName = auth.user_info?.full_name || "Unknown User";

  // 1. Fetch Data on Load
  useEffect(() => {
    // Load Directory
    const dbUsersStr = localStorage.getItem("medivault_users_db");
    let allUsers = dbUsersStr ? JSON.parse(dbUsersStr) : [];
    
    if (allUsers.length === 0) {
      allUsers = [
        { email: "arjun.sharma@email.com", role: "patient", info: PATIENTS[0] },
        { email: "dr.mehta@hospital.com", role: "doctor", info: DOCTORS[0] },
        { email: "admin@hospital.com", role: "admin", info: { full_name: "System Admin" } }
      ];
    }

    let allowedUsers = allUsers.filter(u => u.email !== myEmail);
    if (role === 'patient') allowedUsers = allowedUsers.filter(u => u.role !== 'patient');
    setDirectory(allowedUsers);

    // Load Messages
    const msgsStr = localStorage.getItem("medivault_messages_db");
    let allMsgs = msgsStr ? JSON.parse(msgsStr) : [];

    const myHistory = allMsgs.filter(m => m.to_email === myEmail || m.from_email === myEmail);
    // Sort oldest to newest (better for chat threads)
    setMessages(myHistory.sort((a, b) => a.id.localeCompare(b.id))); 
  }, [myEmail, role]);

  // 2. Process Messages into "Conversations" (WhatsApp Style Grouping)
  const conversations = {};
  messages.forEach(m => {
    const isSentByMe = m.from_email === myEmail;
    const partnerEmail = isSentByMe ? m.to_email : m.from_email;
    
    // Find partner name from directory if possible
    const dirUser = directory.find(u => u.email === partnerEmail);
    const partnerName = dirUser ? dirUser.info?.full_name : (isSentByMe ? m.to_email : m.sender);
    const partnerRole = dirUser ? dirUser.role : "user";

    if (!conversations[partnerEmail]) {
      conversations[partnerEmail] = {
        email: partnerEmail,
        name: partnerName,
        role: partnerRole,
        msgs: [],
        unread: 0
      };
    }
    
    conversations[partnerEmail].msgs.push(m);
    if (!isSentByMe && !m.read) conversations[partnerEmail].unread += 1;
  });

  // Sort conversations by the latest message time
  const chatList = Object.values(conversations).sort((a, b) => {
    const lastA = a.msgs[a.msgs.length - 1].id;
    const lastB = b.msgs[b.msgs.length - 1].id;
    return lastB.localeCompare(lastA);
  });

  const totalUnreadMessages = chatList.reduce((sum, chat) => sum + chat.unread, 0);

  // 3. Mark Chat as Read when opened
  useEffect(() => {
    if (activeChat && conversations[activeChat] && conversations[activeChat].unread > 0) {
      const msgsStr = localStorage.getItem("medivault_messages_db");
      const allMsgs = msgsStr ? JSON.parse(msgsStr) : [];
      
      const newDb = allMsgs.map(m => {
        if (m.to_email === myEmail && m.from_email === activeChat) {
          return { ...m, read: true };
        }
        return m;
      });
      
      localStorage.setItem("medivault_messages_db", JSON.stringify(newDb));
      
      // Update local state to reflect read status
      setMessages(messages.map(m => (m.to_email === myEmail && m.from_email === activeChat ? { ...m, read: true } : m)));
    }
  }, [activeChat, conversations, myEmail, messages]);


  // 4. Send Message Handler
  const handleSendMessage = (targetEmail, text) => {
    if (!text.trim() || !targetEmail) return;

    const msgsStr = localStorage.getItem("medivault_messages_db");
    const allMsgs = msgsStr ? JSON.parse(msgsStr) : [];

    const newMsg = {
      id: 'msg_' + Date.now(),
      to_email: targetEmail,
      from_email: myEmail,
      sender: myName,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      text: text.trim(),
      read: false
    };

    allMsgs.push(newMsg);
    localStorage.setItem("medivault_messages_db", JSON.stringify(allMsgs));
    setMessages([...messages, newMsg]);
  };

  const submitChat = () => {
    handleSendMessage(activeChat, chatInput);
    setChatInput("");
  };

  const startNewChat = () => {
    if (!composeTo) return;
    setActiveTab("messages");
    setActiveChat(composeTo);
    setComposeModal(false);
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 20, height: "calc(100vh - 120px)" }}>
      {/* Header and Toggles */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", flexShrink: 0 }}>
        <div>
          <h2 style={{ margin: 0, color: C.navy, fontSize: 20, fontWeight: 700 }}>Inbox & Alerts</h2>
          <p style={{ margin: "4px 0 0", color: C.gray600, fontSize: 13 }}>Communicate with {role === 'patient' ? "medical staff" : "patients and staff"}</p>
        </div>
        
        <div style={{ display: "flex", gap: 16, alignItems: "center" }}>
          <Btn variant="accent" onClick={() => { setComposeModal(true); if(directory.length > 0) setComposeTo(directory[0].email); }} style={{ padding: "8px 16px" }}>
            <Edit size={16} /> New Chat
          </Btn>

          <div style={{ display: "flex", gap: 8, background: C.gray50, padding: 4, borderRadius: 8, border: `1px solid ${C.gray100}` }}>
            <button 
              onClick={() => { setActiveTab("messages"); setActiveChat(null); }}
              style={{ padding: "6px 16px", borderRadius: 6, border: "none", background: activeTab === "messages" ? "#fff" : "transparent", color: activeTab === "messages" ? C.navy : C.gray600, fontWeight: 600, fontSize: 13, cursor: "pointer", boxShadow: activeTab === "messages" ? "0 1px 3px rgba(0,0,0,0.1)" : "none", transition: "all 0.2s" }}
            >
              Messages {totalUnreadMessages > 0 && <span style={{ background: C.accent, color: "#fff", padding: "2px 6px", borderRadius: 10, fontSize: 10, marginLeft: 4 }}>{totalUnreadMessages}</span>}
            </button>
            <button 
              onClick={() => { setActiveTab("notifications"); setActiveChat(null); }}
              style={{ padding: "6px 16px", borderRadius: 6, border: "none", background: activeTab === "notifications" ? "#fff" : "transparent", color: activeTab === "notifications" ? C.navy : C.gray600, fontWeight: 600, fontSize: 13, cursor: "pointer", boxShadow: activeTab === "notifications" ? "0 1px 3px rgba(0,0,0,0.1)" : "none", transition: "all 0.2s" }}
            >
              Alerts {notifications.filter(n => !n.read).length > 0 && <span style={{ background: C.red, color: "#fff", padding: "2px 6px", borderRadius: 10, fontSize: 10, marginLeft: 4 }}>{notifications.filter(n => !n.read).length}</span>}
            </button>
          </div>
        </div>
      </div>

      {/* Main Content Area */}
      <Card style={{ padding: 0, flex: 1, display: "flex", overflow: "hidden", minHeight: 400 }}>
        
        {/* ─── NOTIFICATIONS TAB ─── */}
        {activeTab === "notifications" ? (
          <div style={{ flex: 1, overflowY: "auto" }}>
            {notifications.map((n, i) => (
              <div 
                key={n.id} onClick={() => setNotifications(notifications.map(x => x.id === n.id ? { ...x, read: true } : x))}
                style={{ display: "flex", gap: 16, padding: "20px 24px", borderBottom: i === notifications.length - 1 ? "none" : `1px solid ${C.gray50}`, background: n.read ? "#fff" : "#F4F8FA", cursor: "pointer" }} 
              >
                <div style={{ marginTop: 2 }}>{n.type === "alert" ? <Calendar size={18} color={C.accent} /> : <FileText size={18} color={C.navyLight} />}</div>
                <div style={{ flex: 1 }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 6 }}>
                    <span style={{ fontWeight: 700, color: C.navy, fontSize: 14 }}>{n.title}</span>
                    <span style={{ fontSize: 11, color: C.gray400 }}>{n.time}</span>
                  </div>
                  <div style={{ color: C.gray600, fontSize: 13, lineHeight: 1.5 }}>{n.text}</div>
                </div>
                {!n.read && <div style={{ width: 8, height: 8, background: C.red, borderRadius: "50%", alignSelf: "center" }} />}
              </div>
            ))}
          </div>
        ) : (
          
        /* ─── MESSAGES TAB (WhatsApp Style Split View) ─── */
          <>
            {/* LEFT PANE: Chat Directory */}
            <div style={{ width: 320, borderRight: `1px solid ${C.gray100}`, display: "flex", flexDirection: "column", background: "#fff" }}>
              <div style={{ padding: "16px", borderBottom: `1px solid ${C.gray50}`, fontWeight: 700, color: C.navy, fontSize: 15 }}>Recent Conversations</div>
              <div style={{ flex: 1, overflowY: "auto" }}>
                {chatList.length === 0 ? (
                   <div style={{ padding: 30, textAlign: "center", color: C.gray400, fontSize: 13 }}>No active chats.</div>
                ) : chatList.map((chat) => {
                  const lastMsg = chat.msgs[chat.msgs.length - 1];
                  const isActive = activeChat === chat.email;
                  
                  return (
                    <div 
                      key={chat.email} 
                      onClick={() => setActiveChat(chat.email)}
                      style={{ display: "flex", gap: 12, padding: "16px", borderBottom: `1px solid ${C.gray50}`, background: isActive ? C.gray50 : "#fff", cursor: "pointer", transition: "background 0.2s" }}
                      onMouseOver={(e) => !isActive && (e.currentTarget.style.background = "#F8FAFC")}
                      onMouseOut={(e) => !isActive && (e.currentTarget.style.background = "#fff")}
                    >
                      <div style={{ width: 44, height: 44, borderRadius: "50%", background: `linear-gradient(135deg, ${C.navyLight}, ${C.accent})`, display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontWeight: 700, fontSize: 16, flexShrink: 0 }}>
                        {chat.name.charAt(4) || chat.name.charAt(0)}
                      </div>
                      <div style={{ flex: 1, overflow: "hidden" }}>
                        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 4 }}>
                          <span style={{ fontWeight: 700, color: C.navy, fontSize: 14, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{chat.name}</span>
                          <span style={{ fontSize: 11, color: chat.unread > 0 ? C.accent : C.gray400, fontWeight: chat.unread > 0 ? 700 : 400 }}>{lastMsg.time}</span>
                        </div>
                        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                          <span style={{ color: chat.unread > 0 ? C.navy : C.gray600, fontSize: 13, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis", fontWeight: chat.unread > 0 ? 600 : 400 }}>
                            {lastMsg.from_email === myEmail ? "You: " : ""}{lastMsg.text}
                          </span>
                          {chat.unread > 0 && <div style={{ background: C.accent, color: "#fff", fontSize: 10, fontWeight: 700, padding: "2px 6px", borderRadius: 10, marginLeft: 8 }}>{chat.unread}</div>}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* RIGHT PANE: Active Thread */}
            <div style={{ flex: 1, display: "flex", flexDirection: "column", background: "#F4F8FA" }}>
              {activeChat ? (
                <>
                  {/* Chat Header */}
                  <div style={{ padding: "16px 24px", background: "#fff", borderBottom: `1px solid ${C.gray100}`, display: "flex", alignItems: "center", gap: 12 }}>
                    <div style={{ width: 40, height: 40, borderRadius: "50%", background: `linear-gradient(135deg, ${C.navyLight}, ${C.accent})`, display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontWeight: 700, fontSize: 14 }}>
                      {conversations[activeChat]?.name.charAt(4) || conversations[activeChat]?.name.charAt(0)}
                    </div>
                    <div>
                      <div style={{ fontWeight: 700, color: C.navy, fontSize: 15 }}>{conversations[activeChat]?.name}</div>
                      <div style={{ color: C.gray400, fontSize: 11, textTransform: "uppercase", letterSpacing: 0.5, marginTop: 2 }}>{conversations[activeChat]?.role}</div>
                    </div>
                  </div>

                  {/* Chat Bubbles */}
                  <div style={{ flex: 1, padding: "24px", overflowY: "auto", display: "flex", flexDirection: "column", gap: 16 }}>
                    {conversations[activeChat]?.msgs.map((m, i) => {
                      const isMe = m.from_email === myEmail;
                      return (
                        <div key={i} style={{ display: "flex", flexDirection: "column", alignItems: isMe ? "flex-end" : "flex-start", width: "100%" }}>
                          <div style={{ 
                            maxWidth: "75%", 
                            padding: "12px 16px", 
                            borderRadius: isMe ? "16px 16px 4px 16px" : "16px 16px 16px 4px", 
                            background: isMe ? C.navy : "#fff", 
                            color: isMe ? "#fff" : C.navy,
                            boxShadow: "0 1px 2px rgba(0,0,0,0.05)",
                            fontSize: 14,
                            lineHeight: 1.5
                          }}>
                            {m.text}
                          </div>
                          <span style={{ fontSize: 10, color: C.gray400, marginTop: 4, padding: "0 4px" }}>{m.time}</span>
                        </div>
                      );
                    })}
                  </div>

                  {/* Chat Input */}
                  <div style={{ padding: "16px 24px", background: "#fff", borderTop: `1px solid ${C.gray100}` }}>
                    <div style={{ display: "flex", gap: 12, alignItems: "center", background: C.gray50, padding: "8px 8px 8px 16px", borderRadius: 24, border: `1px solid ${C.gray100}` }}>
                      <input 
                        type="text" 
                        placeholder="Type a message..." 
                        value={chatInput} 
                        onChange={(e) => setChatInput(e.target.value)} 
                        onKeyDown={(e) => e.key === 'Enter' && submitChat()}
                        style={{ flex: 1, background: "transparent", border: "none", fontSize: 14, outline: "none", color: C.navy }} 
                      />
                      <button onClick={submitChat} disabled={!chatInput.trim()} style={{ width: 36, height: 36, borderRadius: "50%", background: chatInput.trim() ? C.accent : C.gray100, border: "none", display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", cursor: chatInput.trim() ? "pointer" : "default", transition: "background 0.2s" }}>
                        <Send size={16} style={{ marginLeft: -2 }} />
                      </button>
                    </div>
                  </div>
                </>
              ) : (
                <div style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", color: C.gray400 }}>
                  <MessageSquare size={48} style={{ opacity: 0.2, marginBottom: 16 }} />
                  <div style={{ fontSize: 16, fontWeight: 600, color: C.navy }}>Your Messages</div>
                  <div style={{ fontSize: 13, marginTop: 4 }}>Select a conversation from the left to start chatting.</div>
                </div>
              )}
            </div>
          </>
        )}
      </Card>

      {/* ─── NEW CHAT MODAL ─── */}
      {composeModal && (
        <Modal title="Start New Conversation" onClose={() => setComposeModal(false)}>
          <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
            <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
              <label style={{ fontSize: 12, fontWeight: 700, color: C.gray600 }}>SELECT CONTACT</label>
              <select 
                value={composeTo} 
                onChange={e => setComposeTo(e.target.value)}
                style={{ border: `1.5px solid ${C.gray100}`, borderRadius: 8, padding: "10px 12px", fontSize: 13, color: C.navy, outline: "none", background: "#fff" }}
              >
                {directory.length === 0 ? (
                  <option value="">No contacts available</option>
                ) : (
                  directory.map(u => (
                    <option key={u.email} value={u.email}>
                      {u.info?.full_name} ({u.role.toUpperCase()}) - {u.email}
                    </option>
                  ))
                )}
              </select>
            </div>
            <div style={{ display: "flex", justifyContent: "flex-end", gap: 12, marginTop: 8 }}>
              <Btn variant="ghost" onClick={() => setComposeModal(false)}>Cancel</Btn>
              <Btn variant="primary" onClick={startNewChat} disabled={!composeTo}><MessageSquare size={16} /> Open Chat</Btn>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
};

// ─── DOCTOR: MY PATIENTS & CLINICAL NOTES ─────────────────────────────────────
const DoctorPatientsList = ({ auth }) => {
  const [search, setSearch] = useState("");
  const [patientsList, setPatientsList] = useState([]);
  const [selectedPatient, setSelectedPatient] = useState(null);
  
  // Patient Details & History State
  const [patientHistory, setPatientHistory] = useState([]);
  
  // New Note Modal
  const [noteModal, setNoteModal] = useState(false);
  const [noteForm, setNoteForm] = useState({ diagnosis: "", prescription: "", lab_reports: "" });

  // 1. Load All Patients on Mount
  useEffect(() => {
    const dbStr = localStorage.getItem("medivault_users_db");
    let db = dbStr ? JSON.parse(dbStr) : [];
    
    if (db.length === 0) {
      db = PATIENTS.map(p => ({ id: p.patient_id, email: "patient@demo.com", role: "patient", info: p }));
    }
    
    // Only show patients
    setPatientsList(db.filter(u => u.role === "patient"));
  }, []);

  // 2. Load Specific Patient History when selected
  useEffect(() => {
    if (!selectedPatient) return;
    
    const dbStr = localStorage.getItem("medivault_records_db");
    const db = dbStr ? JSON.parse(dbStr) : HEALTH_RECORDS;
    
    // Find records matching this patient's ID
    const history = db.filter(r => r.patient_id === selectedPatient.id);
    setPatientHistory(history.reverse());
  }, [selectedPatient]);

  // 3. Save a new Clinical Note
  const handleSaveNote = () => {
    if (!noteForm.diagnosis) return alert("Diagnosis is required.");

    const dbStr = localStorage.getItem("medivault_records_db");
    const db = dbStr ? JSON.parse(dbStr) : HEALTH_RECORDS;

    const newRecord = {
      record_id: Date.now(),
      patient_id: selectedPatient.id,
      doctor_id: auth.entity_id,
      visit_date: new Date().toISOString().split('T')[0],
      diagnosis: noteForm.diagnosis,
      prescription: noteForm.prescription || "N/A",
      lab_reports: noteForm.lab_reports || "N/A"
    };

    const updatedDb = [newRecord, ...db];
    localStorage.setItem("medivault_records_db", JSON.stringify(updatedDb));
    
    setPatientHistory([newRecord, ...patientHistory]);
    setNoteModal(false);
    setNoteForm({ diagnosis: "", prescription: "", lab_reports: "" });
    alert("Clinical note saved successfully.");
  };

  // 4. Handle Deleting a Clinical Note / Record
  const handleDeleteNote = (recordId) => {
    if (window.confirm("Are you sure you want to delete this medical record? This action cannot be undone.")) {
      // 1. Remove from LocalStorage DB
      const dbStr = localStorage.getItem("medivault_records_db");
      const db = dbStr ? JSON.parse(dbStr) : [];
      const updatedDb = db.filter(r => r.record_id !== recordId);
      localStorage.setItem("medivault_records_db", JSON.stringify(updatedDb));
      
      // 2. Remove from the current UI immediately
      setPatientHistory(patientHistory.filter(r => r.record_id !== recordId));
    }
  };

  const filteredPatients = patientsList.filter(p => 
    p.info?.full_name?.toLowerCase().includes(search.toLowerCase()) || 
    p.email.toLowerCase().includes(search.toLowerCase()) ||
    p.info?.phone?.includes(search)
  );

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
      {/* ─── LIST VIEW ─── */}
      {!selectedPatient ? (
        <>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <div>
              <h2 style={{ margin: 0, color: C.navy, fontSize: 20, fontWeight: 700 }}>Patient Directory</h2>
              <p style={{ margin: "4px 0 0", color: C.gray600, fontSize: 13 }}>Search and view patient medical profiles</p>
            </div>
            <div style={{ position: "relative" }}>
              <Search size={16} color={C.gray400} style={{ position: "absolute", left: 10, top: "50%", transform: "translateY(-50%)" }} />
              <input 
                type="text" placeholder="Search by name, email, or phone..." value={search} onChange={e => setSearch(e.target.value)}
                style={{ padding: "8px 12px 8px 34px", border: `1.5px solid ${C.gray100}`, borderRadius: 8, fontSize: 13, width: 280, outline: "none", color: C.navy }} 
              />
            </div>
          </div>

          <Card style={{ overflowX: "auto", padding: 0 }}>
            <table style={{ width: "100%", borderCollapse: "collapse" }}>
              <thead>
                <tr style={{ background: C.gray50, borderBottom: `2px solid ${C.gray100}` }}>
                  {["Patient Name", "Contact", "Blood Group", "Action"].map(h => (
                    <th key={h} style={{ padding: "14px 20px", textAlign: "left", fontSize: 11, fontWeight: 700, color: C.gray600, letterSpacing: 0.5, textTransform: "uppercase" }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filteredPatients.length === 0 ? (
                  <tr><td colSpan="4" style={{ padding: 40, textAlign: "center", color: C.gray400 }}>No patients found.</td></tr>
                ) : filteredPatients.map(p => (
                  <tr key={p.id} style={{ borderBottom: `1px solid ${C.gray50}` }}>
                    <td style={{ padding: "14px 20px" }}>
                      <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                        <div style={{ width: 36, height: 36, borderRadius: "50%", background: C.accentLight, display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontWeight: 700 }}>
                          {p.info?.full_name?.charAt(0) || "P"}
                        </div>
                        <div>
                          <div style={{ fontWeight: 600, color: C.navy, fontSize: 14 }}>{p.info?.full_name}</div>
                          <div style={{ color: C.gray400, fontSize: 11, marginTop: 2 }}>ID: P-{String(p.id).padStart(4, '0')}</div>
                        </div>
                      </div>
                    </td>
                    <td style={{ padding: "14px 20px" }}>
                      <div style={{ color: C.navy, fontSize: 13 }}>{p.email}</div>
                      <div style={{ color: C.gray400, fontSize: 11, marginTop: 2 }}>{p.info?.phone || "No phone"}</div>
                    </td>
                    <td style={{ padding: "14px 20px" }}>
                      <strong style={{ color: C.red }}>{p.info?.blood_group || "N/A"}</strong>
                    </td>
                    <td style={{ padding: "14px 20px" }}>
                      <Btn variant="outline" onClick={() => setSelectedPatient(p)} style={{ padding: "6px 12px", fontSize: 12 }}>Open Chart</Btn>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </Card>
        </>
      ) : (
        
        /* ─── DETAIL VIEW ─── */
        <>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <Btn variant="ghost" onClick={() => setSelectedPatient(null)} style={{ padding: 0, color: C.gray600 }}>
              <ChevronLeft size={20} /> Back to Directory
            </Btn>
            <Btn variant="accent" onClick={() => setNoteModal(true)}>
              <Plus size={16} /> Add Clinical Note
            </Btn>
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "1fr 2fr", gap: 20 }}>
            {/* Left: Patient Demographics */}
            <Card style={{ padding: 24, alignSelf: "start" }}>
              <div style={{ display: "flex", flexDirection: "column", alignItems: "center", textAlign: "center", borderBottom: `1px solid ${C.gray100}`, paddingBottom: 20, marginBottom: 20 }}>
                <div style={{ width: 80, height: 80, borderRadius: "50%", background: C.gold, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 32, fontWeight: 700, color: C.navy, marginBottom: 12 }}>
                  {selectedPatient.info?.full_name?.charAt(0)}
                </div>
                <h3 style={{ margin: "0 0 4px", color: C.navy, fontSize: 18, fontWeight: 700 }}>{selectedPatient.info?.full_name}</h3>
                <div style={{ color: C.gray600, fontSize: 13 }}>Patient ID: P-{String(selectedPatient.id).padStart(4, '0')}</div>
              </div>
              
              <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
                <div><div style={{ fontSize: 11, color: C.gray400, fontWeight: 600 }}>DATE OF BIRTH</div><div style={{ fontSize: 14, color: C.navy, marginTop: 2 }}>{selectedPatient.info?.date_of_birth || "Unknown"}</div></div>
                <div><div style={{ fontSize: 11, color: C.gray400, fontWeight: 600 }}>BLOOD GROUP</div><div style={{ fontSize: 14, color: C.red, fontWeight: 700, marginTop: 2 }}>{selectedPatient.info?.blood_group || "N/A"}</div></div>
                <div><div style={{ fontSize: 11, color: C.gray400, fontWeight: 600 }}>CONTACT</div><div style={{ fontSize: 14, color: C.navy, marginTop: 2 }}>{selectedPatient.info?.phone || "No phone"}<br/>{selectedPatient.email}</div></div>
                <div><div style={{ fontSize: 11, color: C.gray400, fontWeight: 600 }}>ADDRESS</div><div style={{ fontSize: 14, color: C.navy, marginTop: 2 }}>{selectedPatient.info?.address || "No address provided"}</div></div>
                <div><div style={{ fontSize: 11, color: C.gray400, fontWeight: 600 }}>EMERGENCY CONTACT</div><div style={{ fontSize: 14, color: C.amber, fontWeight: 600, marginTop: 2 }}>{selectedPatient.info?.emergency_contact || "N/A"}</div></div>
              </div>
            </Card>

            {/* Right: Medical History Timeline */}
            <Card style={{ padding: 24, background: "#F8FAFC", border: "none" }}>
              <h3 style={{ margin: "0 0 20px", color: C.navy, fontSize: 16, fontWeight: 700, borderBottom: `1px solid ${C.gray100}`, paddingBottom: 12 }}>Medical History</h3>
              
              <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
                {patientHistory.length === 0 ? (
                  <div style={{ textAlign: "center", color: C.gray400, padding: 40, fontSize: 13 }}>No medical records found for this patient.</div>
                ) : patientHistory.map(record => (
                  <div key={record.record_id} style={{ background: "#fff", border: `1px solid ${C.gray100}`, borderRadius: 10, padding: 16, position: "relative" }}>
                    
                    {/* Header with Title, Date, and Delete Button */}
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 8 }}>
                      <div style={{ fontWeight: 700, color: C.navy, fontSize: 14, flex: 1, paddingRight: 12 }}>
                        {record.attached_file ? record.attached_file.name : record.diagnosis}
                      </div>
                      <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                        <div style={{ color: C.gray400, fontSize: 11 }}>{record.visit_date}</div>
                        
                        {/* The New Delete Button */}
                        <button 
                          onClick={() => handleDeleteNote(record.record_id)}
                          title="Delete Record"
                          style={{ background: "transparent", border: "none", color: C.gray400, padding: 2, cursor: "pointer", transition: "color 0.2s" }}
                          onMouseOver={e => e.currentTarget.style.color = C.red}
                          onMouseOut={e => e.currentTarget.style.color = C.gray400}
                        >
                          <Trash2 size={16} />
                        </button>

                      </div>
                    </div>
                    
                    {record.attached_file ? (
                      <div style={{ fontSize: 13, color: C.accent, display: "flex", alignItems: "center", gap: 6 }}>
                        <FileText size={14} /> Uploaded Document ({record.attached_file.type || "File"})
                      </div>
                    ) : (
                      <div style={{ display: "flex", flexDirection: "column", gap: 6, fontSize: 13, color: C.gray600 }}>
                        <div><strong style={{ color: C.navy }}>Prescription:</strong> {record.prescription}</div>
                        {record.lab_reports && record.lab_reports !== "N/A" && <div><strong style={{ color: C.navy }}>Lab Orders:</strong> {record.lab_reports}</div>}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </Card>
          </div>

          {/* New Clinical Note Modal */}
          {noteModal && (
            <Modal title="Add Clinical Note" onClose={() => setNoteModal(false)}>
              <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
                <div style={{ background: C.gray50, padding: 12, borderRadius: 8, fontSize: 12, color: C.gray600, marginBottom: 4 }}>
                  Creating official medical record for <strong>{selectedPatient.info?.full_name}</strong>
                </div>
                
                <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
                  <label style={{ fontSize: 12, fontWeight: 700, color: C.gray600 }}>DIAGNOSIS / REASON FOR VISIT</label>
                  <input type="text" value={noteForm.diagnosis} onChange={e => setNoteForm({...noteForm, diagnosis: e.target.value})} placeholder="e.g. Acute Bronchitis" style={{ border: `1.5px solid ${C.gray100}`, borderRadius: 8, padding: "10px 12px", fontSize: 13, color: C.navy, outline: "none" }} />
                </div>
                
                <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
                  <label style={{ fontSize: 12, fontWeight: 700, color: C.gray600 }}>PRESCRIPTION</label>
                  <textarea rows="3" value={noteForm.prescription} onChange={e => setNoteForm({...noteForm, prescription: e.target.value})} placeholder="e.g. Amoxicillin 500mg, 3x daily for 7 days" style={{ border: `1.5px solid ${C.gray100}`, borderRadius: 8, padding: "10px 12px", fontSize: 13, color: C.navy, outline: "none", resize: "none", fontFamily: "inherit" }} />
                </div>

                <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
                  <label style={{ fontSize: 12, fontWeight: 700, color: C.gray600 }}>LAB REPORTS / TESTS ORDERED</label>
                  <input type="text" value={noteForm.lab_reports} onChange={e => setNoteForm({...noteForm, lab_reports: e.target.value})} placeholder="e.g. CBC, Chest X-Ray" style={{ border: `1.5px solid ${C.gray100}`, borderRadius: 8, padding: "10px 12px", fontSize: 13, color: C.navy, outline: "none" }} />
                </div>

                <div style={{ display: "flex", justifyContent: "flex-end", gap: 12, marginTop: 10 }}>
                  <Btn variant="ghost" onClick={() => setNoteModal(false)}>Cancel</Btn>
                  <Btn variant="accent" onClick={handleSaveNote} disabled={!noteForm.diagnosis}><Check size={16} /> Save to Records</Btn>
                </div>
              </div>
            </Modal>
          )}
        </>
      )}
    </div>
  );
};

// ─── MAIN APP COMPONENT ───────────────────────────────────────────────────────
export default function App() {
  // Load auth from localStorage on initial render to survive page refreshes
  const [auth, setAuth] = useState(() => {
    try {
      const savedAuth = localStorage.getItem("medivault_session");
      return savedAuth ? JSON.parse(savedAuth) : null;
    } catch (e) {
      return null;
    }
  });
  const [activeView, setActiveView] = useState("dashboard");

  // Custom function to update React state AND save to browser memory
  const handleAuthUpdate = (data) => {
    if (data) {
      localStorage.setItem("medivault_session", JSON.stringify(data));
      setAuth(data);
      setActiveView("dashboard"); // Reset view on login
    } else {
      localStorage.removeItem("medivault_session");
      setAuth(null);
    }
  };

  // Show AuthScreen if no user is logged in
  if (!auth) return <AuthScreen onLogin={handleAuthUpdate} />;

  const renderContent = () => {
    // 1. Dashboards
    if (activeView === "dashboard") {
      if (auth.role === "patient") return <PatientDashboard auth={auth} setActive={setActiveView} />;
      if (auth.role === "doctor") return <DoctorDashboard auth={auth} setActive={setActiveView} />;
      if (auth.role === "admin") return <AdminDashboard auth={auth} setActive={setActiveView} />;
    }
    
    // 2. Shared/Role-Based Modules
    if (activeView === "appointments") return <AppointmentScheduler role={auth.role} auth={auth} />;
    if (activeView === "records" || activeView === "medications") return <HealthRecords auth={auth} activeView={activeView} />;
    if (activeView === "profile") return <UserProfile auth={auth} />;
    if (activeView === "messages") return <MessagesCenter role={auth.role} auth={auth} />;
    if (activeView === "patients" && auth.role === "doctor") return <DoctorPatientsList auth={auth} />;

    // 3. NEW ADMIN-SPECIFIC MODULES
    if (activeView === "users") return <AdminUsers auth = {auth} />;
    if (activeView === "analytics") return <AdminAnalytics />;
    if (activeView === "settings") return <AdminSettings />;
    
    // Fallback
    return <div style={{ textAlign: "center", padding: 50 }}>Module Under Construction</div>;
  };

  return (
    <div style={{ display: "flex", minHeight: "100vh", background: C.gray50 }}>
      {/* Pass handleAuthUpdate(null) to LogOut so it clears localStorage */}
      <Sidebar role={auth.role} active={activeView} setActive={setActiveView} onLogout={() => handleAuthUpdate(null)} />
      
      <div style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden" }}>
        <TopBar title={activeView} userName={auth.user_info?.full_name} setActive={setActiveView} /> 
        
        <main style={{ flex: 1, padding: 28, overflowY: "auto" }}>
          {renderContent()}
        </main>
      </div>
    </div>
  );
}